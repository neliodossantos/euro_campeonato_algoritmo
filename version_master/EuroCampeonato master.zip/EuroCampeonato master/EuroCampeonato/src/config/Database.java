package config;
import java.sql.*;
import java.util.InputMismatchException;
import java.util.Scanner;

public class Database {
    private Connection connection;
    Scanner scanner = new Scanner(System.in);

    // URLs de conexão corrigidas
    String url1 = "jdbc:postgresql://ep-tiny-union-a538wt4z.us-east-2.aws.neon.tech/euro_campeonato?user=euro_campeonato_owner&password=f1hYci5RVQDW&sslmode=require";
    String url2 = "jdbc:postgresql://localhost:5432/euro_campeonato?user=postgres&password=12345678";

    public Database() throws SQLException {
        try {
            Class.forName("org.postgresql.Driver");
            System.out.println("Deseja usar a base de dados?");
            System.out.println("1. Remota (Server Remoto)");
            System.out.println("2. Localhost");
            int op = getUserChoice();
            switch (op) {
                case 1:
                    try {
                        this.connection = DriverManager.getConnection(url1);
                    }catch (Exception e){
                        System.out.println("Ocorreu um erro "+e.getMessage());
                    }
                    break;
                case 2:
                    try {
                        this.connection = DriverManager.getConnection(url2);
                    }catch (Exception e){
                        System.out.println("Ocorreu um erro "+e.getMessage());
                    }
                    break;
                default:
                    System.out.println("Opção inválida. Usando a base de dados localhost por padrão.");
                    this.connection = DriverManager.getConnection(url2);
                    break;
            }
        } catch (SQLException | ClassNotFoundException e) {
            System.out.println("Erro ao conectar ao banco de dados"+e.getMessage());
        }
    }

    private int getUserChoice() {
        while (true) {
            try {
                int choice = scanner.nextInt();
                if (choice == 1 || choice == 2) {
                    return choice;
                } else {
                    System.out.println("Escolha uma opção válida (1 ou 2):");
                }
            } catch (InputMismatchException e) {
                System.out.println("Entrada inválida. Por favor, insira um número.");
                scanner.next(); // clear the invalid input
            }
        }
    }

    public Connection getConnection() {
        return connection;
    }
    public void close() throws SQLException {
        if (connection != null && !connection.isClosed()) {
            connection.close();
        }
    }
}
