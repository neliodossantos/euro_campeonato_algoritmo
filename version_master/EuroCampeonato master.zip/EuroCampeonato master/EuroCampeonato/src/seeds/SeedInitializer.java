package seeds;
import config.Database;
import services.SimularService;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class SeedInitializer {
    private final Database db;
    private final SimularService simularService;

    private static final Scanner scanner = new Scanner(System.in);
    public SeedInitializer(SimularService simularService , Database db) throws SQLException {
        this.simularService = simularService;
        this.db = db;
    }

    public void popularTabelas() throws SQLException {
        if (!verificarDadosExistem("paises")) popularPaises();
        if (!verificarDadosExistem("cidades")) popularCidades();
        if (!verificarDadosExistem("estadios")) popularEstadios();
        if (!verificarDadosExistem("selecoes")) popularSelecoes();
        if (!verificarDadosExistem("grupos")) popularGrupos();
        if (!verificarDadosExistem("selecao_grupo")) popularSelecaoGrupo();
        if (!verificarDadosExistem("jogadores")) popularJogadores();
    }
    private boolean verificarDadosExistem(String tableName) throws SQLException {
        String query = "SELECT COUNT(*) AS count FROM " + tableName;
        try (PreparedStatement stmt = db.getConnection().prepareStatement(query);
             ResultSet rs = stmt.executeQuery()) {
            if (rs.next()) {
                return rs.getInt("count") > 0;
            }
        }
        return false;
    }

    private void popularPaises() {
        List<String> paises = Arrays.asList("Portugal", "Espanha", "França", "Alemanha",
                "Itália", "Inglaterra", "Holanda", "Suíça",
                "Grécia", "Rússia", "Dinamarca", "Suécia",
                "República Tcheca", "Croácia", "Bélgica", "Turquia");

        String insert = "INSERT INTO paises (nome) VALUES (?)";
        try (PreparedStatement stmt = db.getConnection().prepareStatement(insert)) {
            for (String pais : paises) {
                stmt.setString(1, pais);
                stmt.addBatch();
            }
            stmt.executeBatch();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void popularCidades() {
        String[][] cidades = {
                {"Lisboa", "1"}, {"Porto", "1"}, {"Madrid", "2"}, {"Barcelona", "2"},
                {"Paris", "3"}, {"Marselha", "3"}, {"Berlim", "4"}, {"Munique", "4"},
                {"Roma", "5"}, {"Milão", "5"}, {"Londres", "6"}, {"Manchester", "6"},
                {"Amsterdã", "7"}, {"Roterdã", "7"}, {"Zurique", "8"}, {"Genebra", "8"}
        };

        String insert = "INSERT INTO cidades (nome, pais_id) VALUES (?, ?)";
        try (PreparedStatement stmt = db.getConnection().prepareStatement(insert)) {
            for (String[] cidade : cidades) {
                stmt.setString(1, cidade[0]);
                stmt.setInt(2, Integer.parseInt(cidade[1]));
                stmt.addBatch();
            }
            stmt.executeBatch();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void popularEstadios() {
        String[][] estadios = {
                {"Estádio da Luz", "1", "65400"}, {"Estádio do Dragão", "2", "50033"},
                {"Santiago Bernabéu", "3", "81044"}, {"Camp Nou", "4", "99354"},
                {"Parc des Princes", "5", "47929"}, {"Stade Vélodrome", "6", "67394"},
                {"Olympiastadion", "7", "74475"}, {"Allianz Arena", "8", "75000"},
                {"Stadio Olimpico", "9", "72698"}, {"San Siro", "10", "80018"},
                {"Wembley Stadium", "11", "90000"}, {"Old Trafford", "12", "74879"},
                {"Johan Cruyff Arena", "13", "54990"}, {"De Kuip", "14", "51577"},
                {"St. Jakob-Park", "15", "37994"}, {"Stade de Genève", "16", "30000"}
        };

        String insert = "INSERT INTO estadios (nome, cidade_id, capacidade) VALUES (?, ?, ?)";
        try (PreparedStatement stmt = db.getConnection().prepareStatement(insert)) {
            for (String[] estadio : estadios) {
                stmt.setString(1, estadio[0]);
                stmt.setInt(2, Integer.parseInt(estadio[1]));
                stmt.setInt(3, Integer.parseInt(estadio[2]));
                stmt.addBatch();
            }
            stmt.executeBatch();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void popularSelecoes() {
        String[][] selecoes = {
                {"Portugal", "1"}, {"Espanha", "2"}, {"França", "3"},
                {"Alemanha", "4"}, {"Italia", "5"}, {"Inglaterra", "6"},
                {"Holanda", "7"}, {"Suiça", "8"}, {"Grecia", "9"},
                {"Russia", "10"}, {"Dinamarca", "11"}, {"Suecia", "12"},
                {"Republica Tcheca", "13"}, {"Croacia", "14"}, {"Belgica", "15"},
                {"Turquia", "16"}
        };

        String insert = "INSERT INTO selecoes (nome, pais_id) VALUES (?, ?)";
        try (PreparedStatement stmt = db.getConnection().prepareStatement(insert)) {
            for (String[] selecao : selecoes) {
                stmt.setString(1, selecao[0]);
                stmt.setInt(2, Integer.parseInt(selecao[1]));
                stmt.addBatch();
            }
            stmt.executeBatch();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void popularGrupos() {
        List<String> grupos = Arrays.asList("A", "B", "C", "D");

        String insert = "INSERT INTO grupos (nome) VALUES (?)";
        try (PreparedStatement stmt = db.getConnection().prepareStatement(insert)) {
            for (String grupo : grupos) {
                stmt.setString(1, grupo);
                stmt.addBatch();
            }
            stmt.executeBatch();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void popularSelecaoGrupo() {
        int[][] selecaoGrupo = {
                {1, 1}, {1, 2}, {1, 3}, {1, 4},  // Grupo A
                {2, 5}, {2, 6}, {2, 7}, {2, 8},  // Grupo B
                {3, 9}, {3, 10}, {3, 11}, {3, 12},  // Grupo C
                {4, 13}, {4, 14}, {4, 15}, {4, 16}  // Grupo D
        };

        String insert = "INSERT INTO selecao_grupo (grupo_id, selecao_id) VALUES (?, ?)";
        try (PreparedStatement stmt = db.getConnection().prepareStatement(insert)) {
            for (int[] grupoSelecao : selecaoGrupo) {
                stmt.setInt(1, grupoSelecao[0]);
                stmt.setInt(2, grupoSelecao[1]);
                stmt.addBatch();
            }
            stmt.executeBatch();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void popularJogadores() {
        String[][] jogadores = {
                // Portugal
                {"Cristiano Ronaldo", "37", "Atacante", "1"},
                {"Pepe", "39", "Defensor", "1"},
                {"Bruno Fernandes", "27", "Meio-campo", "1"},
                {"João Cancelo", "28", "Defensor", "1"},
                {"Bernardo Silva", "27", "Meio-campo", "1"},
                {"Diogo Jota", "25", "Atacante", "1"},
                {"Ruben Dias", "25", "Defensor", "1"},
                {"João Moutinho", "35", "Meio-campo", "1"},
                {"Renato Sanches", "24", "Meio-campo", "1"},
                {"João Félix", "22", "Atacante", "1"},
                {"Nélson Semedo", "28", "Defensor", "1"},
                {"William Carvalho", "30", "Meio-campo", "1"},
                {"Rui Patrício", "34", "Goleiro", "1"},
                {"Raphaël Guerreiro", "28", "Defensor", "1"},
                {"Gonçalo Guedes", "25", "Atacante", "1"},
                {"Danilo Pereira", "30", "Meio-campo", "1"},
                {"André Silva", "26", "Atacante", "1"},
                {"José Fonte", "38", "Defensor", "1"},
                // Espanha
                {"Sergio Ramos", "36", "Defensor", "2"},
                {"David de Gea", "31", "Goleiro", "2"},
                {"Jordi Alba", "33", "Defensor", "2"},
                {"Sergio Busquets", "33", "Meio-campo", "2"},
                {"Thiago Alcântara", "31", "Meio-campo", "2"},
                {"Koke", "30", "Meio-campo", "2"},
                {"Marco Asensio", "26", "Atacante", "2"},
                {"Ferran Torres", "22", "Atacante", "2"},
                {"Pablo Sarabia", "30", "Atacante", "2"},
                {"Aymeric Laporte", "27", "Defensor", "2"},
                {"Rodri", "25", "Meio-campo", "2"},
                {"Dani Carvajal", "30", "Defensor", "2"},
                {"Marcos Llorente", "27", "Meio-campo", "2"},
                {"Ansu Fati", "19", "Atacante", "2"},
                {"Unai Simón", "24", "Goleiro", "2"},
                {"Mikel Oyarzabal", "24", "Atacante", "2"},
                {"César Azpilicueta", "32", "Defensor", "2"},
                {"Pedri", "19", "Meio-campo", "2"},
                // França
                {"Kylian Mbappé", "23", "Atacante", "3"},
                {"Karim Benzema", "34", "Atacante", "3"},
                {"Antoine Griezmann", "31", "Atacante", "3"},
                {"Paul Pogba", "29", "Meio-campo", "3"},
                {"N'Golo Kanté", "30", "Meio-campo", "3"},
                {"Raphaël Varane", "28", "Defensor", "3"},
                {"Hugo Lloris", "35", "Goleiro", "3"},
                {"Lucas Hernández", "26", "Defensor", "3"},
                {"Presnel Kimpembe", "26", "Defensor", "3"},
                {"Kingsley Coman", "26", "Atacante", "3"},
                {"Benjamin Pavard", "25", "Defensor", "3"},
                {"Lucas Digne", "28", "Defensor", "3"},
                {"Olivier Giroud", "35", "Atacante", "3"},
                {"Adrien Rabiot", "27", "Meio-campo", "3"},
                {"Jules Koundé", "23", "Defensor", "3"},
                {"Mike Maignan", "26", "Goleiro", "3"},
                {"Theo Hernández", "24", "Defensor", "3"},
                {"Wissam Ben Yedder", "31", "Atacante", "3"},
                // Alemanha
                {"Manuel Neuer", "36", "Goleiro", "4"},
                {"Joshua Kimmich", "27", "Meio-campo", "4"},
                {"Leon Goretzka", "27", "Meio-campo", "4"},
                {"Timo Werner", "26", "Atacante", "4"},
                {"Thomas Müller", "32", "Atacante", "4"},
                {"Kai Havertz", "22", "Meio-campo", "4"},
                {"Serge Gnabry", "26", "Atacante", "4"},
                {"Ilkay Gündogan", "31", "Meio-campo", "4"},
                {"Antonio Rüdiger", "29", "Defensor", "4"},
                {"Niklas Süle", "26", "Defensor", "4"},
                {"Mats Hummels", "33", "Defensor", "4"},
                {"Kevin Trapp", "31", "Goleiro", "4"},
                {"Leroy Sané", "26", "Atacante", "4"},
                {"Jamal Musiala", "19", "Meio-campo", "4"},
                {"Emre Can", "28", "Meio-campo", "4"},
                {"Marc-André ter Stegen", "30", "Goleiro", "4"},
                {"Robin Gosens", "27", "Defensor", "4"},
                {"Julian Brandt", "26", "Meio-campo", "4"},
                // Itália
                {"Gianluigi Donnarumma", "23", "Goleiro", "5"},
                {"Leonardo Bonucci", "34", "Defensor", "5"},
                {"Giorgio Chiellini", "37", "Defensor", "5"},
                {"Marco Verratti", "29", "Meio-campo", "5"},
                {"Jorginho", "30", "Meio-campo", "5"},
                {"Federico Chiesa", "24", "Atacante", "5"},
                {"Lorenzo Insigne", "31", "Atacante", "5"},
                {"Ciro Immobile", "32", "Atacante", "5"},
                {"Nicolò Barella", "25", "Meio-campo", "5"},
                {"Alessandro Bastoni", "23", "Defensor", "5"},
                {"Domenico Berardi", "27", "Atacante", "5"},
                {"Andrea Belotti", "28", "Atacante", "5"},
                {"Matteo Pessina", "25", "Meio-campo", "5"},
                {"Gianluca Mancini", "26", "Defensor", "5"},
                {"Alessandro Florenzi", "31", "Defensor", "5"},
                {"Mattia De Sciglio", "29", "Defensor", "5"},
                {"Bryan Cristante", "27", "Meio-campo", "5"},
                {"Salvatore Sirigu", "35", "Goleiro", "5"},
                // Inglaterra
                {"Harry Kane", "28", "Atacante", "6"},
                {"Raheem Sterling", "27", "Atacante", "6"},
                {"Marcus Rashford", "24", "Atacante", "6"},
                {"Harry Maguire", "29", "Defensor", "6"},
                {"John Stones", "28", "Defensor", "6"},
                {"Kyle Walker", "32", "Defensor", "6"},
                {"Jordan Henderson", "31", "Meio-campo", "6"},
                {"Declan Rice", "23", "Meio-campo", "6"},
                {"Mason Mount", "23", "Meio-campo", "6"},
                {"Phil Foden", "22", "Meio-campo", "6"},
                {"Jack Grealish", "26", "Meio-campo", "6"},
                {"Bukayo Saka", "20", "Atacante", "6"},
                {"Ben Chilwell", "25", "Defensor", "6"},
                {"Trent Alexander-Arnold", "23", "Defensor", "6"},
                {"Jadon Sancho", "22", "Atacante", "6"},
                {"Aaron Ramsdale", "23", "Goleiro", "6"},
                {"Luke Shaw", "26", "Defensor", "6"},
                {"Kieran Trippier", "31", "Defensor", "6"},
                // Holanda
                {"Virgil van Dijk", "30", "Defensor", "7"},
                {"Matthijs de Ligt", "22", "Defensor", "7"},
                {"Frenkie de Jong", "25", "Meio-campo", "7"},
                {"Memphis Depay", "28", "Atacante", "7"},
                {"Georginio Wijnaldum", "31", "Meio-campo", "7"},
                {"Denzel Dumfries", "26", "Defensor", "7"},
                {"Steven Bergwijn", "24", "Atacante", "7"},
                {"Donyell Malen", "23", "Atacante", "7"},
                {"Daley Blind", "32", "Defensor", "7"},
                {"Ryan Gravenberch", "20", "Meio-campo", "7"},
                {"Wout Weghorst", "29", "Atacante", "7"},
                {"Jasper Cillessen", "33", "Goleiro", "7"},
                {"Teun Koopmeiners", "24", "Meio-campo", "7"},
                {"Hans Hateboer", "28", "Defensor", "7"},
                {"Stefan de Vrij", "30", "Defensor", "7"},
                {"Davy Klaassen", "29", "Meio-campo", "7"},
                {"Tim Krul", "34", "Goleiro", "7"},
                {"Marten de Roon", "30", "Meio-campo", "7"},
                // Suíça
                {"Granit Xhaka", "29", "Meio-campo", "8"},
                {"Yann Sommer", "33", "Goleiro", "8"},
                {"Xherdan Shaqiri", "30", "Atacante", "8"},
                {"Manuel Akanji", "26", "Defensor", "8"},
                {"Ricardo Rodríguez", "29", "Defensor", "8"},
                {"Denis Zakaria", "25", "Meio-campo", "8"},
                {"Haris Seferovic", "30", "Atacante", "8"},
                {"Breel Embolo", "25", "Atacante", "8"},
                {"Remo Freuler", "30", "Meio-campo", "8"},
                {"Steven Zuber", "30", "Meio-campo", "8"},
                {"Nico Elvedi", "25", "Defensor", "8"},
                {"Fabian Schär", "30", "Defensor", "8"},
                {"Djibril Sow", "25", "Meio-campo", "8"},
                {"Ruben Vargas", "23", "Atacante", "8"},
                {"Gregor Kobel", "24", "Goleiro", "8"},
                {"Silvan Widmer", "29", "Defensor", "8"},
                {"Christian Fassnacht", "28", "Atacante", "8"},
                {"Eray Cömert", "23", "Defensor", "8"},
                // Grécia
                {"Kostas Manolas", "30", "Defensor", "9"},
                {"Sokratis Papastathopoulos", "33", "Defensor", "9"},
                {"Konstantinos Fortounis", "29", "Meio-campo", "9"},
                {"Andreas Samaris", "32", "Meio-campo", "9"},
                {"Dimitris Limnios", "24", "Atacante", "9"},
                {"Petros Mantalos", "30", "Meio-campo", "9"},
                {"Dimitrios Siovas", "33", "Defensor", "9"},
                {"Odysseas Vlachodimos", "28", "Goleiro", "9"},
                {"Anastasios Bakasetas", "28", "Meio-campo", "9"},
                {"Pantelis Hatzidiakos", "24", "Defensor", "9"},
                {"Kostas Tsimikas", "26", "Defensor", "9"},
                {"Giorgos Masouras", "28", "Atacante", "9"},
                {"Vangelis Pavlidis", "23", "Atacante", "9"},
                {"Charis Mavrias", "28", "Meio-campo", "9"},
                {"Zeca", "33", "Meio-campo", "9"},
                {"Kostas Stafylidis", "28", "Defensor", "9"},
                {"Giorgos Tzavellas", "34", "Defensor", "9"},
                {"Alexandros Paschalakis", "32", "Goleiro", "9"},
                // Rússia
                {"Igor Akinfeev", "36", "Goleiro", "10"},
                {"Fyodor Kudryashov", "34", "Defensor", "10"},
                {"Mario Fernandes", "31", "Defensor", "10"},
                {"Dmitri Barinov", "25", "Meio-campo", "10"},
                {"Aleksandr Golovin", "25", "Meio-campo", "10"},
                {"Artem Dzyuba", "33", "Atacante", "10"},
                {"Aleksei Miranchuk", "26", "Meio-campo", "10"},
                {"Roman Zobnin", "28", "Meio-campo", "10"},
                {"Daler Kuzyaev", "29", "Meio-campo", "10"},
                {"Anton Shunin", "35", "Goleiro", "10"},
                {"Vyacheslav Karavaev", "26", "Defensor", "10"},
                {"Magomed Ozdoev", "29", "Meio-campo", "10"},
                {"Rifat Zhemaletdinov", "25", "Atacante", "10"},
                {"Georgi Dzhikiya", "28", "Defensor", "10"},
                {"Andrei Semyonov", "32", "Defensor", "10"},
                {"Igor Smolnikov", "33", "Defensor", "10"},
                {"Nikita Chernov", "26", "Defensor", "10"},
                {"Fyodor Smolov", "32", "Atacante", "10"},
                // Dinamarca
                {"Kasper Schmeichel", "35", "Goleiro", "11"},
                {"Simon Kjær", "33", "Defensor", "11"},
                {"Andreas Christensen", "26", "Defensor", "11"},
                {"Pierre-Emile Højbjerg", "26", "Meio-campo", "11"},
                {"Christian Eriksen", "30", "Meio-campo", "11"},
                {"Yussuf Poulsen", "28", "Atacante", "11"},
                {"Kasper Dolberg", "24", "Atacante", "11"},
                {"Joakim Mæhle", "25", "Defensor", "11"},
                {"Thomas Delaney", "30", "Meio-campo", "11"},
                {"Daniel Wass", "32", "Meio-campo", "11"},
                {"Jannik Vestergaard", "29", "Defensor", "11"},
                {"Andreas Skov Olsen", "22", "Atacante", "11"},
                {"Jonas Wind", "23", "Atacante", "11"},
                {"Christian Nørgaard", "28", "Meio-campo", "11"},
                {"Mikkel Damsgaard", "21", "Meio-campo", "11"},
                {"Nicolai Boilesen", "30", "Defensor", "11"},
                {"Robert Skov", "25", "Atacante", "11"},
                {"Frederik Rønnow", "29", "Goleiro", "11"},
                // Suécia
                {"Zlatan Ibrahimović", "40", "Atacante", "12"},
                {"Emil Forsberg", "30", "Meio-campo", "12"},
                {"Victor Lindelöf", "27", "Defensor", "12"},
                {"Robin Olsen", "32", "Goleiro", "12"},
                {"Alexander Isak", "22", "Atacante", "12"},
                {"Dejan Kulusevski", "22", "Meio-campo", "12"},
                {"Albin Ekdal", "32", "Meio-campo", "12"},
                {"Sebastian Larsson", "36", "Meio-campo", "12"},
                {"Marcus Berg", "35", "Atacante", "12"},
                {"Filip Helander", "28", "Defensor", "12"},
                {"Mikael Lustig", "35", "Defensor", "12"},
                {"Ludwig Augustinsson", "27", "Defensor", "12"},
                {"Emil Krafth", "27", "Defensor", "12"},
                {"Jesper Karlsson", "23", "Atacante", "12"},
                {"Kristoffer Olsson", "26", "Meio-campo", "12"},
                {"Pontus Jansson", "31", "Defensor", "12"},
                {"Mattias Svanberg", "23", "Meio-campo", "12"},
                {"Carl Starfelt", "27", "Defensor", "12"},
                // República Tcheca
                {"Tomáš Vaclík", "32", "Goleiro", "13"},
                {"Tomáš Souček", "27", "Meio-campo", "13"},
                {"Vladimír Coufal", "29", "Defensor", "13"},
                {"Patrik Schick", "26", "Atacante", "13"},
                {"Antonín Barák", "27", "Meio-campo", "13"},
                {"Jakub Jankto", "26", "Meio-campo", "13"},
                {"Alex Král", "23", "Meio-campo", "13"},
                {"Adam Hložek", "19", "Atacante", "13"},
                {"Tomáš Kalas", "28", "Defensor", "13"},
                {"Michael Krmenčík", "28", "Atacante", "13"},
                {"Ondřej Čelůstka", "32", "Defensor", "13"},
                {"Jan Bořil", "30", "Defensor", "13"},
                {"Pavel Kadeřábek", "29", "Defensor", "13"},
                {"David Zima", "21", "Defensor", "13"},
                {"Filip Novák", "31", "Defensor", "13"},
                {"Tomáš Holes", "28", "Meio-campo", "13"},
                {"Jiří Pavlenka", "29", "Goleiro", "13"},
                {"Matěj Vydra", "29", "Atacante", "13"},
                // Croácia
                {"Luka Modrić", "36", "Meio-campo", "14"},
                {"Ivan Perišić", "33", "Atacante", "14"},
                {"Andrej Kramarić", "30", "Atacante", "14"},
                {"Ivan Rakitić", "34", "Meio-campo", "14"},
                {"Mateo Kovačić", "29", "Meio-campo", "14"},
                {"Josko Gvardiol", "20", "Defensor", "14"},
                {"Dejan Lovren", "34", "Defensor", "14"},
                {"Domagoj Vida", "33", "Defensor", "14"},
                {"Šime Vrsaljko", "30", "Defensor", "14"},
                {"Ante Rebić", "28", "Atacante", "14"},
                {"Josip Brekalo", "24", "Atacante", "14"},
                {"Mislav Oršić", "29", "Atacante", "14"},
                {"Lovro Majer", "24", "Meio-campo", "14"},
                {"Nikola Vlašić", "25", "Meio-campo", "14"},
                {"Dominik Livaković", "27", "Goleiro", "14"},
                {"Marcelo Brozović", "29", "Meio-campo", "14"},
                {"Borna Barišić", "29", "Defensor", "14"},
                {"Lovre Kalinić", "31", "Goleiro", "14"},
                {"Mario Pašalić", "28", "Meio-campo", "14"},
                // Áustria
                {"David Alaba", "31", "Defensor", "15"},
                {"Marko Arnautović", "34", "Atacante", "15"},
                {"Marcel Sabitzer", "29", "Meio-campo", "15"},
                {"Stefan Lainer", "30", "Defensor", "15"},
                {"Martin Hinteregger", "30", "Defensor", "15"},
                {"Christoph Baumgartner", "22", "Meio-campo", "15"},
                {"Konrad Laimer", "26", "Meio-campo", "15"},
                {"Aleksandar Dragović", "31", "Defensor", "15"},
                {"Xaver Schlager", "24", "Meio-campo", "15"},
                {"Michael Gregoritsch", "28", "Atacante", "15"},
                {"Florian Grillitsch", "26", "Meio-campo", "15"},
                {"Daniel Bachmann", "28", "Goleiro", "15"},
                {"Louis Schaub", "27", "Meio-campo", "15"},
                {"Andreas Ulmer", "36", "Defensor", "15"},
                {"Philipp Lienhart", "26", "Defensor", "15"},
                {"Alessandro Schöpf", "27", "Meio-campo", "15"},
                {"Pavao Pervan", "34", "Goleiro", "15"},
                {"Valentino Lazaro", "26", "Meio-campo", "15"},
                // Polônia
                {"Robert Lewandowski", "35", "Atacante", "16"},
                {"Krzysztof Piątek", "27", "Atacante", "16"},
                {"Arkadiusz Milik", "29", "Atacante", "16"},
                {"Piotr Zieliński", "28", "Meio-campo", "16"},
                {"Grzegorz Krychowiak", "32", "Meio-campo", "16"},
                {"Kamil Glik", "34", "Defensor", "16"},
                {"Wojciech Szczęsny", "33", "Goleiro", "16"},
                {"Kamil Grosicki", "34", "Atacante", "16"},
                {"Jan Bednarek", "26", "Defensor", "16"},
                {"Mateusz Klich", "31", "Meio-campo", "16"},
                {"Karol Linetty", "27", "Meio-campo", "16"},
                {"Łukasz Fabiański", "38", "Goleiro", "16"},
                {"Tomasz Kędziora", "27", "Defensor", "16"},
                {"Przemysław Frankowski", "27", "Meio-campo", "16"},
                {"Bartosz Bereszyński", "30", "Defensor", "16"},
                {"Jakub Moder", "23", "Meio-campo", "16"},
                {"Maciej Rybus", "32", "Defensor", "16"},
                {"Tymoteusz Puchacz", "24", "Defensor", "16"}
            };

            String insert = "INSERT INTO jogadores (nome, idade, posicao,selecao_id) VALUES (?, ?,?,?)";
            try (PreparedStatement stmt = db.getConnection().prepareStatement(insert)) {
                for (String [] jogador : jogadores ) {
                    stmt.setString(1, jogador[0]);
                    stmt.setInt(2, Integer.parseInt(jogador[1]));
                    stmt.setString(3, jogador[2]);
                    stmt.setInt(4, Integer.parseInt(jogador[3]));
                    stmt.addBatch();
                }
                stmt.executeBatch();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        public boolean simularEuro() throws SQLException {
            if (!verificarDadosExistem("partidas")){
                if(!verificarDadosExistem("cartao")){
                    if(!verificarDadosExistem("eventos")){
                        if(!verificarDadosExistem("estatisticas_globais_equipe")){
                            if(!verificarDadosExistem("estatisticas_individuais")){
                                if(!verificarDadosExistem("substituicao")){
                                    if(!verificarDadosExistem("golo")){
                                        System.out.println("Deseja simular o euro?");
                                        System.out.println("Selecione uma opção: ");
                                        System.out.println(" 1.Sim | 2.Nao ");
                                        int op  = scanner.nextInt();
                                        switch (op){
                                            case 1:
                                                this.simularService.simular();
                                                return true;
                                            case 2:
                                                break;
                                            default:
                                                System.out.println("Opção inválida. Tente novamente.");
                                                break;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            return false;
        }

        public void simularNovamente(){
            System.out.println("Deseja simular novamente euro?");
            System.out.println("Selecione uma opção: ");
            System.out.println(" 1.Sim | 2.Nao ");
            int op  = scanner.nextInt();
            switch (op){
                case 1:
                    this.simularService.simular();
                    break;
                case 2:
                    break;
                default:
                    System.out.println("Opção inválida. Tente novamente.");
                    break;
            }
        }
}
