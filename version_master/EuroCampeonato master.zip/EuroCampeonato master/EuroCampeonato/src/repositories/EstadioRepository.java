package repositories;
import config.Database;
import entities.Cidade;
import entities.Estadio;
import entities.Pais;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class EstadioRepository {
    private Database conn;

    private CidadeRepository cidadeRepository;
    public EstadioRepository(Database conn) {
        this.conn = conn;
        this.cidadeRepository = new CidadeRepository(conn);
    }
    public void createEstadios(Estadio estadio) {
        String sql = "INSERT INTO estadios (nome) VALUES (?,?,?)";
        try (PreparedStatement pstmt = conn.getConnection().prepareStatement(sql)) {
            pstmt.setString(1, estadio.getNome());
            pstmt.setInt(2, estadio.getCity().getId());
            pstmt.setInt(3, estadio.getCapacity());

            pstmt.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("Ocorreu um erro!" + e.getMessage());
        }
    }

    public List<Estadio> getAllEstadios() {
        String sql = "SELECT e.nome AS nome_estadio , e.capacidade , c.nome AS nome_cidade FROM estadios AS e INNER JOIN cidade AS c ON c.id = e.cidade_id ";
        try (Statement stmt = conn.getConnection().createStatement()) {
            ResultSet rs = stmt.executeQuery(sql);
            List<Estadio> estadios = new ArrayList<>();
            while (rs.next()) {
                Estadio estadio = new Estadio();
                Cidade cidade = new Cidade();
                estadio.setId(rs.getInt("id"));
                estadio.setNome(rs.getString("nome_estadio"));
                estadio.getCity().setNome(rs.getString("nome_cidade"));
                estadios.add(estadio);
            }
            return estadios;
        } catch (SQLException e) {
            throw new RuntimeException("Ocorreu um erro!" + e.getMessage());
        }
    }

    public List<Estadio> getAllEstadiosByCidade(int cidade_id) {
        String sql = "SELECT * FROM estadios WHERE cidade_id = ?";
        try (PreparedStatement pstmt = conn.getConnection().prepareStatement(sql)) {
            pstmt.setInt(1, cidade_id);  // Corrigido para definir o primeiro parâmetro como selecao_id
            ResultSet rs = pstmt.executeQuery();
            List<Estadio> estadios = new ArrayList<>();
            while (rs.next()) {
                Estadio estadio = new Estadio();
                estadio.setId(rs.getInt("id"));
                estadio.setNome(rs.getString("nome"));
                estadios.add(estadio);
            }
            return estadios;
        } catch (SQLException e) {
            throw new RuntimeException("Ocorreu um erro!" + e.getMessage());
        }
    }

    public Estadio getEstadio(int id) {
        String sql = "SELECT * FROM estadios WHERE id = ?";
        try (PreparedStatement pstmt = conn.getConnection().prepareStatement(sql)) {
            pstmt.setInt(1, id);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                Estadio estadio = new Estadio();
                estadio.setId(rs.getInt("id"));
                estadio.setNome(rs.getString("nome"));
                estadio.setCapacity(rs.getInt("capacidade"));
                return estadio;
            } else {
                return null;
            }
        } catch (SQLException e) {
            throw new RuntimeException("Ocorreu um erro!" + e.getMessage());
        }
    }

    public void updateEstadios(Pais pais) {
        String sql = "UPDATE estadios SET nome = ? WHERE id = ?";
        try (PreparedStatement pstmt = conn.getConnection().prepareStatement(sql)) {
            pstmt.setString(1, pais.getNome());
            pstmt.setInt(2, pais.getId());
            pstmt.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("Ocorreu um erro!" + e.getMessage());
        }
    }

    public void deleteEstadios(int id) {
        String sql = "DELETE FROM estadios WHERE id = ?";
        try (PreparedStatement pstmt = conn.getConnection().prepareStatement(sql)) {
            pstmt.setInt(1, id);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("Ocorreu um erro!" + e.getMessage());
        }
    }
    public int getIdByName(String nome) {
        String sql = "SELECT id FROM estadios WHERE nome = ?";
        try (PreparedStatement pstmt = conn.getConnection().prepareStatement(sql)) {
            pstmt.setString(1, nome);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt("id");  // Pega o ID do resultado
                } else {
                    return -1;  // Indica que o nome não foi encontrado
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException("Ocorreu um erro!" + e.getMessage());
        }
    }
}
