package repositories;

import config.Database;
import entities.Selecao;
import entities.SelecaoGrupo;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class SelecaoGrupoRepository {
    private final Database conn;

    public SelecaoGrupoRepository(Database conn) {
        this.conn = conn;
    }

    public void createSelecaoGrupo(SelecaoGrupo selecaoGrupo) {
        String sql = "INSERT INTO selecao_grupo (grupo_id, selecao_id, pontos, jogos, vitorias, empates, derrotas, gols_pro, gols_contra) " +
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (PreparedStatement pstmt = conn.getConnection().prepareStatement(sql)) {
            pstmt.setInt(1, selecaoGrupo.getGrupoId());
            pstmt.setInt(2, selecaoGrupo.getSelecao().getId());
            pstmt.setInt(3, selecaoGrupo.getPontos());
            pstmt.setInt(4, selecaoGrupo.getJogos());
            pstmt.setInt(5, selecaoGrupo.getVitorias());
            pstmt.setInt(6, selecaoGrupo.getEmpates());
            pstmt.setInt(7, selecaoGrupo.getDerrotas());
            pstmt.setInt(8, selecaoGrupo.getGolsPro());
            pstmt.setInt(9, selecaoGrupo.getGolsContra());
            pstmt.executeUpdate();
            System.out.println("Seleção no grupo criada com sucesso!");
        } catch (SQLException e) {
            throw new RuntimeException("Ocorreu um erro!" + e.getMessage());
        }
    }

    public List<SelecaoGrupo> getSelecoesPorGrupo(int grupoId) {
        List<SelecaoGrupo> selecoes = new ArrayList<>();
        String query = "SELECT sg.id, sg.grupo_id, sg.selecao_id, sg.pontos, sg.jogos, sg.vitorias, sg.empates, sg.derrotas, sg.gols_pro, sg.gols_contra, s.nome " +
                "FROM selecao_grupo sg " +
                "JOIN selecoes s ON sg.selecao_id = s.id " +
                "WHERE sg.grupo_id = ?";
        try (PreparedStatement stmt = conn.getConnection().prepareStatement(query)) {
            stmt.setInt(1, grupoId);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Selecao selecao = new Selecao(rs.getInt("selecao_id"), rs.getString("nome"));
                SelecaoGrupo selecaoGrupo = new SelecaoGrupo(
                        rs.getInt("id"),
                        rs.getInt("grupo_id"),
                        selecao,
                        rs.getInt("pontos"),
                        rs.getInt("jogos"),
                        rs.getInt("vitorias"),
                        rs.getInt("empates"),
                        rs.getInt("derrotas"),
                        rs.getInt("gols_pro"),
                        rs.getInt("gols_contra")
                );
                selecoes.add(selecaoGrupo);
            }
        } catch (SQLException e) {
            throw new RuntimeException("Ocorreu um erro!" + e.getMessage());
        }
        return selecoes;
    }

    public SelecaoGrupo getById(int id) {
        String query = "SELECT sg.id, sg.grupo_id, sg.selecao_id, sg.pontos, sg.jogos, sg.vitorias, sg.empates, sg.derrotas, sg.gols_pro, sg.gols_contra, s.nome " +
                "FROM selecao_grupo sg " +
                "JOIN selecoes s ON sg.selecao_id = s.id " +
                "WHERE sg.id = ?";
        try (PreparedStatement stmt = conn.getConnection().prepareStatement(query)) {
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                Selecao selecao = new Selecao(rs.getInt("selecao_id"), rs.getString("nome"));
                return new SelecaoGrupo(
                        rs.getInt("id"),
                        rs.getInt("grupo_id"),
                        selecao,
                        rs.getInt("pontos"),
                        rs.getInt("jogos"),
                        rs.getInt("vitorias"),
                        rs.getInt("empates"),
                        rs.getInt("derrotas"),
                        rs.getInt("gols_pro"),
                        rs.getInt("gols_contra")
                );
            } else {
                return null;
            }
        } catch (SQLException e) {
            throw new RuntimeException("Ocorreu um erro!" + e.getMessage());
        }
    }
    public SelecaoGrupo getBySelecaoId(int selecaoId) {
        String query = "SELECT sg.id, sg.grupo_id, sg.selecao_id, sg.pontos, sg.jogos, sg.vitorias, sg.empates, sg.derrotas, sg.gols_pro, sg.gols_contra, s.nome " +
                "FROM selecao_grupo sg " +
                "JOIN selecoes s ON sg.selecao_id = s.id " +
                "WHERE sg.selecao_id = ?";
        try (PreparedStatement stmt = conn.getConnection().prepareStatement(query)) {
            stmt.setInt(1, selecaoId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                Selecao selecao = new Selecao(rs.getInt("selecao_id"), rs.getString("nome"));
                return new SelecaoGrupo(
                        rs.getInt("id"),
                        rs.getInt("grupo_id"),
                        selecao,
                        rs.getInt("pontos"),
                        rs.getInt("jogos"),
                        rs.getInt("vitorias"),
                        rs.getInt("empates"),
                        rs.getInt("derrotas"),
                        rs.getInt("gols_pro"),
                        rs.getInt("gols_contra")
                );
            } else {
                return null;
            }
        } catch (SQLException e) {
            throw new RuntimeException("Ocorreu um erro!" + e.getMessage());
        }
    }

    public void updateSelecaoGrupo(SelecaoGrupo selecaoGrupo) {
        String sql = "UPDATE selecao_grupo SET pontos = ?, jogos = ?, vitorias = ?, empates = ?, derrotas = ?, gols_pro = ?, gols_contra = ? " +
                "WHERE id = ?";
        try (PreparedStatement pstmt = conn.getConnection().prepareStatement(sql)) {
            pstmt.setInt(1, selecaoGrupo.getPontos());
            pstmt.setInt(2, selecaoGrupo.getJogos());
            pstmt.setInt(3, selecaoGrupo.getVitorias());
            pstmt.setInt(4, selecaoGrupo.getEmpates());
            pstmt.setInt(5, selecaoGrupo.getDerrotas());
            pstmt.setInt(6, selecaoGrupo.getGolsPro());
            pstmt.setInt(7, selecaoGrupo.getGolsContra());
            pstmt.setInt(8, selecaoGrupo.getId());
            pstmt.executeUpdate();
            System.out.println("Seleção no grupo atualizada com sucesso!");
        } catch (SQLException e) {
            throw new RuntimeException("Ocorreu um erro!" + e.getMessage());
        }
    }

    public void deleteSelecaoGrupo(int id) {
        String sql = "DELETE FROM selecao_grupo WHERE id = ?";
        try (PreparedStatement pstmt = conn.getConnection().prepareStatement(sql)) {
            pstmt.setInt(1, id);
            pstmt.executeUpdate();
            System.out.println("Seleção no grupo deletada com sucesso!");
        } catch (SQLException e) {
            throw new RuntimeException("Ocorreu um erro!" + e.getMessage());
        }
    }
}
