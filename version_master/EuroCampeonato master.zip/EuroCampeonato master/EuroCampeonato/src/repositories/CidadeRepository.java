package repositories;
import config.Database;
import entities.Cidade;
import entities.Cidade;
import entities.Pais;
import entities.Player;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class CidadeRepository {
    private Database conn;
    private SelecaoRepository selecaoRepository = new SelecaoRepository(conn);
    public CidadeRepository(Database conn) {
        this.conn = conn;
    }

    public void createCidade(Cidade cidade) {
        String sql = "INSERT INTO cidades (nome,pais_id) VALUES (?,?)";
        try (PreparedStatement pstmt = conn.getConnection().prepareStatement(sql)) {
            pstmt.setString(1, cidade.getNome());
            pstmt.setInt(2, cidade.getPais().getId());
            pstmt.executeUpdate();
            System.out.println("Criado com sucesso!");
        } catch (SQLException e) {
            throw new RuntimeException("Ocorreu um erro!" + e.getMessage());
        }
    }
    public List<Cidade> getAllCountries() {
        String sql = "SELECT * FROM cidades";
        try (Statement stmt = conn.getConnection().createStatement()) {
            ResultSet rs = stmt.executeQuery(sql);
            List<Cidade> cidades = new ArrayList<>();
            while (rs.next()) {
                Cidade cidade = new Cidade();
                cidade.setId(rs.getInt("id"));
                cidade.setNome(rs.getString("nome"));
                cidades.add(cidade);
            }
            return cidades;
        } catch (SQLException e) {
            throw new RuntimeException("Ocorreu um erro!" + e.getMessage());
        }
    }

    public List<Cidade> getAllCidadesByPais(int pais_id) {
        String sql = "SELECT * FROM cidades WHERE pais_id = ?";
        try (PreparedStatement pstmt = conn.getConnection().prepareStatement(sql)) {
            pstmt.setInt(1, pais_id);  // Corrigido para definir o primeiro parâmetro como selecao_id
            ResultSet rs = pstmt.executeQuery();
            List<Cidade> cidades = new ArrayList<>();
            while (rs.next()) {
                Cidade cidade = new Cidade();
                cidade.setId(rs.getInt("id"));
                cidade.setNome(rs.getString("nome"));
                cidades.add(cidade);
            }
            return cidades;
        } catch (SQLException e) {
            throw new RuntimeException("Ocorreu um erro!" + e.getMessage());
        }
    }

    public Cidade getCountry(int id) {
        String sql = "SELECT * FROM countries WHERE id = ?";
        try (PreparedStatement pstmt = conn.getConnection().prepareStatement(sql)) {
            pstmt.setLong(1, id);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                Cidade cidade = new Cidade();
                cidade.setId(rs.getInt("id"));
                cidade.setNome(rs.getString("nome"));
                return cidade;
            } else {
                return null;
            }
        } catch (SQLException e) {
            throw new RuntimeException("Ocorreu um erro!" + e.getMessage());
        }
    }

    public void updateCountry(Cidade cidade) {
        String sql = "UPDATE countries SET nome = ? WHERE id = ?";
        try (PreparedStatement pstmt = conn.getConnection().prepareStatement(sql)) {
            pstmt.setString(1, cidade.getNome());
            pstmt.setInt(2, cidade.getId());
            pstmt.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("Ocorreu um erro!" + e.getMessage());
        }
    }

    public void deleteCountry(int id) {
        String sql = "DELETE FROM countries WHERE id = ?";
        try (PreparedStatement pstmt = conn.getConnection().prepareStatement(sql)) {
            pstmt.setInt(1, id);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("Ocorreu um erro!" + e.getMessage());
        }
    }

    public Cidade getById(int id) {
        Cidade cidade  = new Cidade();
        String sql = "SELECT * FROM cidades WHERE id = ?";
        try (PreparedStatement pstmt = conn.getConnection().prepareStatement(sql)) {
            pstmt.setInt(1, id);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    cidade.setId(rs.getInt("id"));// Pega o ID do resultado
                    cidade.setNome(rs.getString("nome"));
                    PaisRepository paisRepository = new PaisRepository(conn);
                    Pais getPais = paisRepository.getById(rs.getInt("pais_id"));
                    cidade.setPais(getPais);
                } else {
                    return null;  // Indica que o nome não foi encontrado
                }
            }
            return cidade;
        } catch (SQLException e) {
            throw new RuntimeException("Ocorreu um erro!" + e.getMessage());
        }
    }

    public int getIdByName(String nome) {
        String sql = "SELECT id FROM cidades WHERE nome = ?";
        try (PreparedStatement pstmt = conn.getConnection().prepareStatement(sql)) {
            pstmt.setString(1, nome);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt("id");  // Pega o ID do resultado
                } else {
                    return -1;  // Indica que o nome não foi encontrado
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException("Ocorreu um erro!" + e.getMessage());
        }
    }

}
