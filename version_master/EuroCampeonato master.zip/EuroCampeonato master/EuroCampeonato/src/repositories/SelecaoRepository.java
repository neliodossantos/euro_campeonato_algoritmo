package repositories;
import config.Database;
import entities.Grupo;
import entities.Pais;
import entities.Selecao;
import entities.SelecaoGrupo;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class SelecaoRepository {
    private Database conn;

    public SelecaoRepository(Database conn) {
        this.conn = conn;
    }

    public void createSelecao(Selecao selecao) {
        String sql = "INSERT INTO selecoes (nome,pais_id) VALUES (?,?)";
        try (PreparedStatement pstmt = conn.getConnection().prepareStatement(sql)) {
            pstmt.setString(1, selecao.getNome());
            pstmt.setInt(2, selecao.getCountry().getId());
            pstmt.executeUpdate();
            System.out.println("Criado com sucesso!");
        } catch (SQLException e) {
            throw new RuntimeException("Ocorreu um erro!" + e.getMessage());
        }
    }

    public List<Selecao> getAllSelecao() {
        String sql = "SELECT * FROM selecoes";
        try (Statement stmt = conn.getConnection().createStatement()) {
            ResultSet rs = stmt.executeQuery(sql);
            List<Selecao> selecaos = new ArrayList<>();
            while (rs.next()) {
                Selecao selecao = new Selecao();
                selecao.setId(rs.getInt("id"));
                selecao.setNome(rs.getString("nome"));
                selecaos.add(selecao);
            }
            return selecaos;
        } catch (SQLException e) {
            throw new RuntimeException("Ocorreu um erro!" + e.getMessage());
        }
    }

    public Selecao getSelecao(int id) {
        String sql = "SELECT * FROM selecoes WHERE id = ?";
        try (PreparedStatement pstmt = conn.getConnection().prepareStatement(sql)) {
            pstmt.setLong(1, id);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                Selecao country = new Selecao();
                country.setId(rs.getInt("id"));
                country.setNome(rs.getString("nome"));
                return country;
            } else {
                return null;
            }
        } catch (SQLException e) {
            throw new RuntimeException("Ocorreu um erro!" + e.getMessage());
        }
    }

    public void updateCountry(Selecao country) {
        String sql = "UPDATE selecoes SET nome = ? WHERE id = ?";
        try (PreparedStatement pstmt = conn.getConnection().prepareStatement(sql)) {
            pstmt.setString(1, country.getNome());
            pstmt.setInt(2, country.getId());
            pstmt.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("Ocorreu um erro!" + e.getMessage());
        }
    }

    public void deleteCountry(int id) {
        String sql = "DELETE FROM selecoes WHERE id = ?";
        try (PreparedStatement pstmt = conn.getConnection().prepareStatement(sql)) {
            pstmt.setInt(1, id);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("Ocorreu um erro!" + e.getMessage());
        }
    }
    public int getIdByName(String nome) {
        String sql = "SELECT id FROM selecoes WHERE nome = ?";
        try (PreparedStatement pstmt = conn.getConnection().prepareStatement(sql)) {
            pstmt.setString(1, nome);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt("id");  // Pega o ID do resultado
                } else {
                    return -1;  // Indica que o nome não foi encontrado
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException("Ocorreu um erro!" + e.getMessage());
        }
    }

    public Selecao getById(int id) {
        Selecao selecao  = new Selecao();
        String sql = "SELECT * FROM selecoes WHERE id = ?";
        try (PreparedStatement pstmt = conn.getConnection().prepareStatement(sql)) {
            pstmt.setInt(1, id);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    selecao.setId(rs.getInt("id"));// Pega o ID do resultado
                    selecao.setNome(rs.getString("nome"));
                    PaisRepository paisRepository = new PaisRepository(conn);
                    Pais getPais = paisRepository.getById(rs.getInt("pais_id"));
                    selecao.setCountry(getPais);
                } else {
                    return null;  // Indica que o nome não foi encontrado
                }
            }
            return selecao;
        } catch (SQLException e) {
            throw new RuntimeException("Ocorreu um erro!" + e.getMessage());
        }
    }
    public void consultarEstatisticasEquipe(Grupo grupo, SelecaoGrupo selecaoGrupo) {
        String query = "SELECT sg.id, sg.pontos, sg.jogos, sg.vitorias, sg.empates, sg.derrotas, sg.gols_pro, sg.gols_contra, " +
                "ege.remates, ege.livres, ege.foras_de_jogo " +
                "FROM selecao_grupo sg " +
                "JOIN estatisticas_globais_equipe ege ON sg.selecao_id = ege.selecao_id " +
                "WHERE sg.grupo_id = ? AND sg.selecao_id = ?";
        try (PreparedStatement stmt = conn.getConnection().prepareStatement(query)) {
            stmt.setInt(1, grupo.getId());
            stmt.setInt(2, selecaoGrupo.getSelecao().getId());
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                int pontos = rs.getInt("pontos");
                int jogos = rs.getInt("jogos");
                int vitorias = rs.getInt("vitorias");
                int empates = rs.getInt("empates");
                int derrotas = rs.getInt("derrotas");
                int golsPro = rs.getInt("gols_pro");
                int golsContra = rs.getInt("gols_contra");
                int remates = rs.getInt("remates");
                int livres = rs.getInt("livres");
                int forasDeJogo = rs.getInt("foras_de_jogo");

                System.out.println("Estatísticas da Seleção " + selecaoGrupo.getSelecao().getNome() + " no Grupo " + grupo.getNome() + ":");
                System.out.println("Pontos: " + pontos);
                System.out.println("Jogos: " + jogos);
                System.out.println("Gols Contra: " + golsContra);
                System.out.println("Remates: " + remates);
                System.out.println("Livres: " + livres);
                System.out.println("Foras de Jogo: " + forasDeJogo);
            } else {
                System.out.println("Não foram encontradas estatísticas para a Seleção  " + selecaoGrupo.getSelecao().getNome() + " no Grupo " + grupo.getNome());
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


}
