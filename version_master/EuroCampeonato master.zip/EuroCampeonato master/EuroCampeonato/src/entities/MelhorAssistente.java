package entities;

public class MelhorAssistente {
    private int jogadorId;
    private int numAssistencias;

    public MelhorAssistente(int jogadorId, int numAssistencias) {
        this.jogadorId = jogadorId;
        this.numAssistencias = numAssistencias;
    }

    // Getters e Setters (opcional)
    public int getJogadorId() {
        return jogadorId;
    }

    public void setJogadorId(int jogadorId) {
        this.jogadorId = jogadorId;
    }

    public int getNumAssistencias() {
        return numAssistencias;
    }

    public void setNumAssistencias(int numAssistencias) {
        this.numAssistencias = numAssistencias;
    }
}
