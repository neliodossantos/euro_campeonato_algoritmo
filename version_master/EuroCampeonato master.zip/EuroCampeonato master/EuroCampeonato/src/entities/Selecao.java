package entities;

import java.util.ArrayList;
import java.util.List;

public class Selecao {
    private int id;
    private String nome;
    private Pais pais;
    private List<Player> players;

    public Selecao(){};

    public Selecao(int id, String nome) {
        this.id = id;
        this.nome = nome;
        this.pais = pais;
        this.players = new ArrayList<Player>();
    }
    public Selecao(int id, String nome, Pais pais) {
        this.id = id;
        this.nome = nome;
        this.pais = pais;
        this.players = new ArrayList<>();
    }

    // Getters e Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Pais getCountry() {
        return pais;
    }

    public void setCountry(Pais pais) {
        this.pais = pais;
    }

    public List<Player> getPlayers() {
        return players;
    }

    public void setPlayers(List<Player> players) {
        this.players = players;
    }

}

