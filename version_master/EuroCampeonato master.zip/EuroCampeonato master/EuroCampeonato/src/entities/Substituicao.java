package entities;

public class Substituicao {
}
