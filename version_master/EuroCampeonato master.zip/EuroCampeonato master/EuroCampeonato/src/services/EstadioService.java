package services;
import entities.Estadio;
import entities.Cidade;
import repositories.CidadeRepository;
import repositories.EstadioRepository;

import java.util.List;
import java.util.Scanner;

public class EstadioService {
    private final CidadeRepository cidadeRepository;
    private final EstadioRepository estadioRepository;

    public EstadioService(CidadeRepository cidadeService , EstadioRepository estadioRepository){
        this.cidadeRepository = cidadeService;
        this.estadioRepository  = estadioRepository;
    }
    public void criarEstadio(Scanner scanner){
        System.out.println("Digite o nome da cidade: ");
        String nome_cidade = scanner.next();
        int getCidadeID = cidadeRepository.getIdByName(nome_cidade);
        if(getCidadeID > 0){
            System.out.println("Digite o nome do estadio: ");
            String nome_estadio = scanner.next();
            Estadio estadio = new Estadio();
            Cidade cidade = new Cidade();
            estadio.setNome(nome_estadio);
            cidade  = cidadeRepository.getById(getCidadeID);
            estadio.setCity(cidade);
            estadioRepository.createEstadios(estadio);
        }else{
            System.out.println("Não encontrou o pais, não é possivel criar cidade");
        }
    }

    public void listarEstadio(Scanner scanner){
        System.out.println("Digite o nome da cidade: ");
        String nome_pais = scanner.next();
        int getCidadeID = cidadeRepository.getIdByName(nome_pais);
        if(getCidadeID > 0 ){
            List<Estadio> estadios =  estadioRepository.getAllEstadiosByCidade(getCidadeID);
            for(Estadio estadio : estadios){
                System.out.println("Nome: " + estadio.getNome());
            }
        }else{
            System.out.println("Não encontrou a seleção.");
        }
    }
}
