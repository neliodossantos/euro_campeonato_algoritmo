package services;

import entities.Grupo;
import repositories.GrupoRepository;

import java.util.Scanner;

public class GrupoService {

    private GrupoRepository grupoRepository;

    public GrupoService(GrupoRepository grupoRepository){
        this.grupoRepository = grupoRepository;
    }

    public void criarGrupo(Scanner scanner){
        System.out.println("Digite o nome do grupo: ");
        String nome_grupo = scanner.next();
        Grupo grupo = new Grupo();
        grupo.setNome(nome_grupo);
        grupoRepository.createGrupo(grupo);
    }
    public void listarGrupo(Scanner scanner){
        System.out.println("Digite o nome do Grupo:");
        String nome_grupo = scanner.next();
        int getGrupoID = grupoRepository.getIdByName(nome_grupo);
        if(getGrupoID > 0){
            grupoRepository.imprimirSelecoesPorGrupo(getGrupoID);
        }else{
            System.out.println("Não encontrou o grupo");
        }
    }


}

