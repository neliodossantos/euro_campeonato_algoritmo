package services;
import config.Database;
import entities.Partida;
import entities.Player;
import entities.Selecao;
import entities.SelecaoGrupo;
import repositories.JogadorRepository;
import repositories.PartidaRepository;
import repositories.SelecaoRepository;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class PartidaService {
    private final Database conn;
    private final JogadorRepository jogadorRepository;

    private final SelecaoRepository selecaoRepository;
    private  final PartidaRepository partidaRepository;

    public PartidaService(Database conn , JogadorRepository jogadorRepository , SelecaoRepository selecaoRepository,
                          PartidaRepository partidaRepository) {
        this.jogadorRepository = jogadorRepository;
        this.conn = conn;
        this.partidaRepository = partidaRepository;
        this.selecaoRepository = selecaoRepository;
    }

    // Método para gerar partidas com base nas seleções de cada grupo
    public List<Partida> generatePartidas(List<SelecaoGrupo> selecoesGrupos, int estadioId) {
        List<Partida> partidas = new ArrayList<>();

        for (int i = 0; i < selecoesGrupos.size(); i++) {
            for (int j = i + 1; j < selecoesGrupos.size(); j++) {
                if (partidas.size() < 6) { // Limitar a 6 partidas por grupo (exemplo)
                    Selecao selecaoCasa = selecoesGrupos.get(i).getSelecao();
                    JogadorRepository jogadorRepository = new JogadorRepository(conn);
                    Selecao selecaoFora = selecoesGrupos.get(j).getSelecao();
                    List<Player> jogadoresCasa = jogadorRepository.getAllJogadoresBySelecao(selecaoCasa.getId());
                    List<Player> jogadoresFora = jogadorRepository.getAllJogadoresBySelecao(selecaoFora.getId());
                    selecaoCasa.setPlayers(jogadoresFora);
                    selecaoFora.setPlayers(jogadoresCasa);
                    int grupoID = selecoesGrupos.get(i).getGrupoId(); // Mesmo grupo para ambas as seleções
                    Partida partida = new Partida(selecaoCasa, selecaoFora);
                    partida.setGrupoId(grupoID);
                    partida.setEstadio_id(estadioId); // Definir o estádio
                    partidas.add(partida);
                }
            }
        }
        return partidas;
    }

    public void imprimirPartida(Scanner scanner){
        System.out.println("Digite o numero da partida");
        int id = scanner.nextInt();

        int getId = partidaRepository.getId(id);


        if(getId>0){
            Partida partida = partidaRepository.buscarPartida(id);
            Selecao selecaoCasa = selecaoRepository.getSelecao(partida.getSelecao1().getId());
            Selecao selecaoFora = selecaoRepository.getSelecao(partida.getSelecao2().getId());
            System.out.println("Partida: " + partida.getId());
            System.out.println("Selecao Casa  " + selecaoCasa.getNome() + " - golos : " + partida.getGols1());
            System.out.println("Selecao Fora  " + selecaoFora.getNome() + " - golos " + partida.getGols2());
        }else{
            System.out.println("Id não encontrado");
        }
    }
}
