package utils;

public class ScreenUtils {
    public void pause(String texto){
        try {
            System.out.println(texto);
            Thread.sleep(1000); // Pausa por 1 segundo (1000 milissegundos)
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        //System.out.println("Texto após a pausa");
    }

    public void clear() {
        try {
            String os = System.getProperty("os.name").toLowerCase();
            ProcessBuilder processBuilder;
            processBuilder = new ProcessBuilder("cmd", "/c", "cls");
            Process process = processBuilder.inheritIO().start();
            process.waitFor();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
