package config;
import java.sql.*;
import java.util.Scanner;

public class Database {
    private Connection connection;
    Scanner scanner = new Scanner(System.in);

    // URL de conexão corrigida
    String url1 = "jdbc:postgresql://localhost:5432/euro_campeonato?user=postgres&password=12345678";
    String url2 = "jdbc:postgresql://ep-tiny-union-a538wt4z.us-east-2.aws.neon.tech/euro_campeonato?user=euro_campeonato_owner&password=f1hYci5RVQDW&sslmode=require";

    public Database() throws SQLException {
        try {
            Class.forName("org.postgresql.Driver");
            System.out.println("Deseja usar a base de dados?");
            System.out.println("1.Remota(Server Remoto)");
            System.out.println("2.Localhost");
            int op  = scanner.nextInt();
            switch (op){
                case 1:
                    this.connection = DriverManager.getConnection(url1);
                    break;
                case 2:
                    this.connection = DriverManager.getConnection(url2);
                    break;
                default:
                    System.out.println("Escolha uma opcao");
                    break;
            }
        } catch (SQLException | ClassNotFoundException e) {
            throw new SQLException("Erro ao conectar ao banco de dados", e);
        }
    }

    public Connection getConnection() {
        return connection;
    }
    public void close() throws SQLException {
        if (connection != null && !connection.isClosed()) {
            connection.close();
        }
    }
}
