CREATE DATABASE euro_campeonato;

CREATE TABLE paises (
    id SERIAL PRIMARY KEY,
    nome VARCHAR(255) NOT NULL
);

CREATE TABLE cidades (
     id SERIAL PRIMARY KEY,
     nome VARCHAR(255) NOT NULL,
     pais_id INT,
     FOREIGN KEY (pais_id) REFERENCES paises(id)
);

CREATE TABLE estadios (
      id SERIAL PRIMARY KEY,
      nome VARCHAR(255) NOT NULL,
      cidade_id INT,
      capacidade INT,
      FOREIGN KEY (cidade_id) REFERENCES cidades(id)
);

CREATE TABLE selecoes (
      id SERIAL PRIMARY KEY,
      nome VARCHAR(255) NOT NULL,
      pais_id INT,
      FOREIGN KEY (pais_id) REFERENCES paises(id)
);

CREATE TABLE jogadores (
       id SERIAL PRIMARY KEY,
       nome VARCHAR(255) NOT NULL,
       idade INT,
       posicao VARCHAR(255),
       selecao_id INT,
       FOREIGN KEY (selecao_id) REFERENCES selecoes(id)
);

CREATE TABLE partidas (
      id SERIAL PRIMARY KEY,
      selecao_casa_id INT,
      selecao_fora_id INT,
      estadio_id INT,
      data_hora TIMESTAMP,
      FOREIGN KEY (selecao_casa_id) REFERENCES selecoes(id),
      FOREIGN KEY (selecao_fora_id) REFERENCES selecoes(id),
      FOREIGN KEY (estadio_id) REFERENCES estadios(id)
);

CREATE TABLE eventos (
     id SERIAL PRIMARY KEY,
     tipo VARCHAR(255),
     jogador_id INT,
     minuto INT,
     partida_id INT,
     FOREIGN KEY (jogador_id) REFERENCES jogadores(id),
     FOREIGN KEY (partida_id) REFERENCES partidas(id)
);

CREATE TABLE grupos (
    id SERIAL PRIMARY KEY,
    nome VARCHAR(1) NOT NULL
);

CREATE TABLE selecao_grupo (
           id SERIAL PRIMARY KEY,
           grupo_id INT NOT NULL,
           selecao_id INT NOT NULL,
           pontos INT DEFAULT 0,
           jogos INT DEFAULT 0,
           vitorias INT DEFAULT 0,
           empates INT DEFAULT 0,
           derrotas INT DEFAULT 0,
           gols_pro INT DEFAULT 0,
           gols_contra INT DEFAULT 0,
           FOREIGN KEY (grupo_id) REFERENCES grupos(id),
           FOREIGN KEY (selecao_id) REFERENCES selecoes(id)
);
