package repositories;
import config.Database;
import entities.Player;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class JogadorRepository {
    private Database conn;

    private SelecaoRepository selecaoRepository;

    public JogadorRepository(Database conn) {
        this.conn = conn;
        this.selecaoRepository = new SelecaoRepository(conn);
    }


    public void createJogador(Player player) {
        String sql = "INSERT INTO jogadores (nome,idade,posicao,selecao_id) VALUES (?,?,?,?)";
        try (PreparedStatement pstmt = conn.getConnection().prepareStatement(sql)) {
            pstmt.setString(1, player.getNome());
            pstmt.setInt(2, player.getIdade());
            pstmt.setString(3, player.getPosicao());
            pstmt.setInt(4, player.getTeam().getId());
            pstmt.executeUpdate();
            System.out.println("Criado com sucesso!");
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public List<Player> getAllJogadores() {
        String sql = "SELECT * FROM jogadores";
        try (Statement stmt = conn.getConnection().createStatement()) {
            ResultSet rs = stmt.executeQuery(sql);
            List<Player> players = new ArrayList<>();
            while (rs.next()) {
                Player player = new Player();
                player.setId(rs.getInt("id"));
                player.setNome(rs.getString("nome"));
                player.setIdade(rs.getInt("idade"));  // Recupera a idade do jogador
                player.setPosicao(rs.getString("posicao"));  // Recupera a posição do jogador, se necessário
                players.add(player);
            }
            return players;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
    public List<Player> getAllJogadoresBySelecao(int selecao_id) {
        String sql = "SELECT * FROM jogadores WHERE selecao_id = ?";
        try (PreparedStatement pstmt = conn.getConnection().prepareStatement(sql)) {
            pstmt.setInt(1, selecao_id);  // Corrigido para definir o primeiro parâmetro como selecao_id
            ResultSet rs = pstmt.executeQuery();
            List<Player> players = new ArrayList<>();
            while (rs.next()) {
                Player player = new Player();
                player.setId(rs.getInt("id"));
                player.setNome(rs.getString("nome"));
                player.setIdade(rs.getInt("idade"));  // Recupera a idade do jogador
                player.setPosicao(rs.getString("posicao"));  // Recupera a posição do jogador, se necessário
                players.add(player);
            }
            return players;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
    public List<Player> getPlayeresBySelecao(int selecao_id) {
        String sql = "SELECT * FROM jogadores WHERE selecao_id = ?";
        try (PreparedStatement pstmt = conn.getConnection().prepareStatement(sql)) {
            pstmt.setInt(1, selecao_id);  // Corrigido para definir o primeiro parâmetro como selecao_id
            ResultSet rs = pstmt.executeQuery();
            List<Player> players = new ArrayList<>();
            while (rs.next()) {
                Player player = new Player();
                player.setId(rs.getInt("id"));
                player.setNome(rs.getString("nome"));
                player.setIdade(rs.getInt("idade"));  // Recupera a idade do jogador
                player.setPosicao(rs.getString("posicao"));  // Recupera a posição do jogador, se necessário
                players.add(player);
            }
            return players;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
    public int getIdByName(String nome) {
        String sql = "SELECT id FROM jogadores WHERE nome = ?";
        try (PreparedStatement pstmt = conn.getConnection().prepareStatement(sql)) {
            pstmt.setString(1, nome);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt("id");  // Pega o ID do resultado
                } else {
                    return -1;  // Indica que o nome não foi encontrado
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
    public Player getPlayer(int id) {
        String sql = "SELECT * FROM jogadores WHERE id = ?";
        try (PreparedStatement pstmt = conn.getConnection().prepareStatement(sql)) {
            pstmt.setLong(1, id);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                Player player = new Player();
                player.setId(rs.getInt("id"));
                player.setNome(rs.getString("nome"));
                return player;
            } else {
                return null;
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
    public void updateJogador(Player jogador) {
        String sql = "UPDATE players SET nome = ? WHERE id = ?";
        try (PreparedStatement pstmt = conn.getConnection().prepareStatement(sql)) {
            pstmt.setString(1, jogador.getNome());
            pstmt.setInt(2, jogador.getId());
            pstmt.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public void deleteJogador(int id) {
        String sql = "DELETE FROM players WHERE id = ?";
        try (PreparedStatement pstmt = conn.getConnection().prepareStatement(sql)) {
            pstmt.setInt(1, id);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public void listarJogadoresEquipe(String nome_equipa){
        int getSelecaoID = selecaoRepository.getIdByName(nome_equipa);
        if(getSelecaoID > 0 ){
            List<Player> jogadores =  this.getAllJogadoresBySelecao(getSelecaoID);
            for(Player jogador : jogadores){
                System.out.println(" Nome: " + jogador.getNome() + " Idade: " + jogador.getIdade() + " Posição: " + jogador.getPosicao());
            }
        }else{
            System.out.println("Não encontrou a seleção.");
        }
    }
}
