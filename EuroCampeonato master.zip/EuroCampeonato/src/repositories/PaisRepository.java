package repositories;
import config.Database;
import entities.Pais;
import entities.Pais;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class PaisRepository {
    private Database conn;

    public PaisRepository(Database conn) {
        this.conn = conn;
    }

    public void createPais(Pais pais) {
        String sql = "INSERT INTO paises (nome) VALUES (?)";
        try (PreparedStatement pstmt = conn.getConnection().prepareStatement(sql)) {
            pstmt.setString(1, pais.getNome());
            pstmt.executeUpdate();
            System.out.println("Criado com sucesso!");
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
    public List<Pais> getAllCountries() {
        String sql = "SELECT * FROM paises";
        try (Statement stmt = conn.getConnection().createStatement()) {
            ResultSet rs = stmt.executeQuery(sql);
            List<Pais> paiss = new ArrayList<>();
            while (rs.next()) {
                Pais pais = new Pais();
                pais.setId(rs.getInt("id"));
                pais.setNome(rs.getString("nome"));
                paiss.add(pais);
            }
            return paiss;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public Pais getCountry(int id) {
        String sql = "SELECT * FROM paises WHERE id = ?";
        try (PreparedStatement pstmt = conn.getConnection().prepareStatement(sql)) {
            pstmt.setLong(1, id);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                Pais pais = new Pais();
                pais.setId(rs.getInt("id"));
                pais.setNome(rs.getString("nome"));
                return pais;
            } else {
                return null;
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public void updateCountry(Pais pais) {
        String sql = "UPDATE paises SET nome = ? WHERE id = ?";
        try (PreparedStatement pstmt = conn.getConnection().prepareStatement(sql)) {
            pstmt.setString(1, pais.getNome());
            pstmt.setInt(2, pais.getId());
            pstmt.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public void deleteCountry(int id) {
        String sql = "DELETE FROM paises WHERE id = ?";
        try (PreparedStatement pstmt = conn.getConnection().prepareStatement(sql)) {
            pstmt.setInt(1, id);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public Pais getById(int id) {
        Pais pais  = new Pais();
        String sql = "SELECT * FROM paises WHERE id = ?";
        try (PreparedStatement pstmt = conn.getConnection().prepareStatement(sql)) {
            pstmt.setInt(1, id);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    pais.setId(rs.getInt("id"));// Pega o ID do resultado
                    pais.setNome(rs.getString("nome"));
                } else {
                    return null;  // Indica que o nome não foi encontrado
                }
            }
            return pais;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public int getIdByName(String nome) {
        String sql = "SELECT id FROM paises WHERE nome = ?";
        try (PreparedStatement pstmt = conn.getConnection().prepareStatement(sql)) {
            pstmt.setString(1, nome);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt("id");  // Pega o ID do resultado
                } else {
                    return -1;  // Indica que o nome não foi encontrado
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
}
