package repositories;
import config.Database;
import entities.*;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class PartidaRepository {
    private Database conn;

    public PartidaRepository(Database conn) {
        this.conn = conn;
    }

    // Método para inserir partidas no banco de dados
    public void insertPartidas(List<Partida> partidas) throws SQLException {
        String insertPartidaSQL = "INSERT INTO partidas (gols_selecao1, gols_selecao2, selecao_casa_id, selecao_fora_id, estadio_id, grupo_id) " +
                "VALUES (?, ?, ?, ?, ?, ?)";
        try (PreparedStatement ps = conn.getConnection().prepareStatement(insertPartidaSQL, PreparedStatement.RETURN_GENERATED_KEYS)) {
            for (Partida partida : partidas) {
                ps.setInt(1, partida.getGols1()); // Gols da seleção casa
                ps.setInt(2, partida.getGols2()); // Gols da seleção fora
                ps.setInt(3, partida.getSelecao1().getId()); // ID da seleção casa
                ps.setInt(4, partida.getSelecao2().getId()); // ID da seleção fora
                ps.setInt(5, partida.getEstadio_id()); // ID do estádio
                ps.setInt(6, partida.getGrupoId()); // ID do grupo
                ps.addBatch();
            }
            ps.executeBatch();
            ResultSet rs = ps.getGeneratedKeys();
            int i = 0;
            while (rs.next()) {
                int partidaId = rs.getInt(1);
                partidas.get(i).setId(partidaId); // Definir o ID da partida para cada objeto Partida
                i++;
            }
        }
    }

    // Método para simular partidas e atualizar informações
    public void simularPartidas(List<Partida> partidas) throws SQLException {
        Random rand = new Random();
        String insertEventoSQL = "INSERT INTO eventos (tipo, jogador_id, minuto, partida_id) " +
                "VALUES (?, ?, ?, ?)";
        String insertSubstituicaoSQL = "INSERT INTO substituicao (partida_id, jogador_sai_id, jogador_entra_id, minuto) " +
                "VALUES (?, ?, ?, ?)";
        String insertGoloSQL = "INSERT INTO golo (partida_id, jogador_id, minuto) " +
                "VALUES (?, ?, ?)";
        String insertCartaoSQL = "INSERT INTO cartao (partida_id, jogador_id, tipo, minuto) " +
                "VALUES (?, ?, ?, ?)";
        String updatePartidaSQL = "UPDATE partidas SET gols_selecao1 = ?, gols_selecao2 = ? WHERE id = ?";

        String updateEstatisticasEquipeSQL = "UPDATE estatisticas_globais_equipe " +
                "SET remates = remates + ?, livres = livres + ?, foras_de_jogo = foras_de_jogo + ? " +
                "WHERE partida_id = ? AND selecao_id = ?";

        String updateEstatisticasIndividuaisSQL = "UPDATE estatisticas_individuais " +
                "SET passes = passes + ?, assistencias = assistencias + ?, remates = remates + ?, minutos_jogados = minutos_jogados + ? " +
                "WHERE partida_id = ? AND jogador_id = ?";
        String updateClassificacaoSQL = "UPDATE selecao_grupo " +
                "SET pontos = pontos + ?, jogos = jogos + 1, vitorias = vitorias + ?, empates = empates + ?, derrotas = derrotas + ?, " +
                "gols_pro = gols_pro + ?, gols_contra = gols_contra + ? " +
                "WHERE selecao_id = ? AND grupo_id = ?";
        String insertEstatisticasIndividuaisSQL = "INSERT INTO estatisticas_individuais " +
                "(partida_id, jogador_id, passes, assistencias, remates, minutos_jogados) " +
                "VALUES (?, ?, ?, ?, ?, ?)";

        String insertEstatisticasGlobaisEquipeSQL = "INSERT INTO estatisticas_globais_equipe " +
                "(partida_id, selecao_id, remates, livres, foras_de_jogo) " +
                "VALUES (?, ?, ?, ?, ?)";


        try (PreparedStatement psUpdatePartida = conn.getConnection().prepareStatement(updatePartidaSQL);
             PreparedStatement psInsertEvento = conn.getConnection().prepareStatement(insertEventoSQL);
             PreparedStatement psInsertSubstituicao = conn.getConnection().prepareStatement(insertSubstituicaoSQL);
             PreparedStatement psInsertGolo = conn.getConnection().prepareStatement(insertGoloSQL);
             PreparedStatement psInsertCartao = conn.getConnection().prepareStatement(insertCartaoSQL);
             PreparedStatement psInsertEstatisticasIndividuais = conn.getConnection().prepareStatement(insertEstatisticasIndividuaisSQL);
             PreparedStatement psInsertEstatisticasEquipe = conn.getConnection().prepareStatement(insertEstatisticasGlobaisEquipeSQL);


             PreparedStatement psUpdateEstatisticasEquipe = conn.getConnection().prepareStatement(updateEstatisticasEquipeSQL);
             PreparedStatement psUpdateEstatisticasIndividuais = conn.getConnection().prepareStatement(updateEstatisticasIndividuaisSQL);
             PreparedStatement psUpdateClassificacao = conn.getConnection().prepareStatement(updateClassificacaoSQL)) {

            for (Partida partida : partidas) {
                int golsCasa = rand.nextInt(5);
                int golsFora = rand.nextInt(5);
                partida.setGols1(golsCasa);
                partida.setGols2(golsFora);

                // Atualizar tabela de partidas com os gols
                psUpdatePartida.setInt(1, golsCasa);
                psUpdatePartida.setInt(2, golsFora);
                psUpdatePartida.setInt(3, partida.getId());
                psUpdatePartida.addBatch();

                // Simular eventos durante a partida (exemplo simplificado)
                simularEventos(partida, psInsertEvento, psInsertSubstituicao, psInsertGolo, psInsertCartao);

                // Atualizar estatísticas globais da equipe e individuais dos jogadores
                atualizarEstatisticasIndividuais(partida, psUpdateEstatisticasIndividuais, psInsertEstatisticasIndividuais);
                // Chama o método para atualizar estatísticas globais da equipe para cada partida
                atualizarEstatisticasGlobaisEquipe(partida, psUpdateEstatisticasEquipe, psInsertEstatisticasEquipe);
                // Atualizar classificação do grupo
                atualizarClassificacao(partida, psUpdateClassificacao);
            }

            // Executar todas as atualizações em batch
            psUpdatePartida.executeBatch();
            psInsertEvento.executeBatch();
            psInsertSubstituicao.executeBatch();
            psInsertGolo.executeBatch();
            psInsertCartao.executeBatch();
            psUpdateEstatisticasEquipe.executeBatch();
            psUpdateEstatisticasIndividuais.executeBatch();
            psUpdateClassificacao.executeBatch();
        }
    }

    private void atualizarEstatisticasIndividuais(Partida partida, PreparedStatement psUpdateEstatisticasIndividuais, PreparedStatement psInsertEstatisticasIndividuais) throws SQLException {
        Random rand = new Random();

        // Atualizar estatísticas individuais para jogadores da seleção casa
        for (Player jogador : partida.getSelecao1().getPlayers()) {
            int partidaId = partida.getId();
            int jogadorId = jogador.getId();

            // Verificar se já existe uma entrada para esta partida e jogador
            if (existeEstatisticaIndividuais(partidaId, jogadorId)) {
                // Atualizar estatísticas existentes
                int passes = rand.nextInt(50);
                int assistencias = rand.nextInt(10);
                int rematesJogador = rand.nextInt(5);
                int minutosJogados = rand.nextInt(90);

                psUpdateEstatisticasIndividuais.setInt(1, passes);
                psUpdateEstatisticasIndividuais.setInt(2, assistencias);
                psUpdateEstatisticasIndividuais.setInt(3, rematesJogador);
                psUpdateEstatisticasIndividuais.setInt(4, minutosJogados);
                psUpdateEstatisticasIndividuais.setInt(5, partidaId);
                psUpdateEstatisticasIndividuais.setInt(6, jogadorId);
                psUpdateEstatisticasIndividuais.addBatch();
            } else {
                // Inserir novas estatísticas
                int passes = rand.nextInt(50);
                int assistencias = rand.nextInt(10);
                int rematesJogador = rand.nextInt(5);
                int minutosJogados = rand.nextInt(90);

                psInsertEstatisticasIndividuais.setInt(1, partidaId);
                psInsertEstatisticasIndividuais.setInt(2, jogadorId);
                psInsertEstatisticasIndividuais.setInt(3, passes);
                psInsertEstatisticasIndividuais.setInt(4, assistencias);
                psInsertEstatisticasIndividuais.setInt(5, rematesJogador);
                psInsertEstatisticasIndividuais.setInt(6, minutosJogados);
                psInsertEstatisticasIndividuais.addBatch();
            }
        }

        // Executar batch para atualização e inserção de estatísticas individuais
        psUpdateEstatisticasIndividuais.executeBatch();
        psInsertEstatisticasIndividuais.executeBatch();
    }

    // Verificar se existe uma entrada para estatísticas individuais desta partida e jogador
    private boolean existeEstatisticaIndividuais(int partidaId, int jogadorId) throws SQLException {
        String query = "SELECT COUNT(*) FROM estatisticas_individuais WHERE partida_id = ? AND jogador_id = ?";
        try (PreparedStatement ps = conn.getConnection().prepareStatement(query)) {
            ps.setInt(1, partidaId);
            ps.setInt(2, jogadorId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                int count = rs.getInt(1);
                return count > 0;
            }
            return false;
        }
    }


    // Método para simular eventos durante a partida
    private void simularEventos(Partida partida, PreparedStatement psInsertEvento, PreparedStatement psInsertSubstituicao,
                                PreparedStatement psInsertGolo, PreparedStatement psInsertCartao) throws SQLException {
        Random rand = new Random();
        // Exemplo: simular 10 eventos (gol, substituição, cartão)
        for (int i = 0; i < 10; i++) {
            int minuto = rand.nextInt(90) + 1; // Simular evento em algum minuto entre 1 e 90

            // Simular gol
            if (rand.nextDouble() < 0.2) { // Probabilidade de 20% de ocorrer um gol
                int jogadorId = partida.getSelecao1().getPlayers().get(rand.nextInt(partida.getSelecao1().getPlayers().size())).getId();
                System.out.println("Inserindo gol: partida_id=" + partida.getId() + ", jogador_id=" + jogadorId + ", minuto=" + minuto); // Debug
                psInsertGolo.setInt(1, partida.getId());
                psInsertGolo.setInt(2, jogadorId);
                psInsertGolo.setInt(3, minuto);
                psInsertGolo.addBatch();
            }

            // Simular cartão
            if (rand.nextDouble() < 0.1) { // Probabilidade de 10% de ocorrer um cartão
                int jogadorId = partida.getSelecao2().getPlayers().get(rand.nextInt(partida.getSelecao2().getPlayers().size())).getId();
                String tipoCartao = rand.nextBoolean() ? "amarelo" : "vermelho";
                System.out.println("Inserindo cartão: partida_id=" + partida.getId() + ", jogador_id=" + jogadorId + ", tipo=" + tipoCartao + ", minuto=" + minuto); // Debug
                psInsertCartao.setInt(1, partida.getId());
                psInsertCartao.setInt(2, jogadorId);
                psInsertCartao.setString(3, tipoCartao);
                psInsertCartao.setInt(4, minuto);
                psInsertCartao.addBatch();
            }

            // Simular substituição
            if (rand.nextDouble() < 0.15) { // Probabilidade de 15% de ocorrer uma substituição
                int jogadorSaiId = partida.getSelecao1().getPlayers().get(rand.nextInt(partida.getSelecao1().getPlayers().size())).getId();
                int jogadorEntraId = partida.getSelecao1().getPlayers().get(rand.nextInt(partida.getSelecao1().getPlayers().size())).getId();
                System.out.println("Inserindo substituição: partida_id=" + partida.getId() + ", jogador_sai_id=" + jogadorSaiId + ", jogador_entra_id=" + jogadorEntraId + ", minuto=" + minuto); // Debug
                psInsertSubstituicao.setInt(1, partida.getId());
                psInsertSubstituicao.setInt(2, jogadorSaiId);
                psInsertSubstituicao.setInt(3, jogadorEntraId);
                psInsertSubstituicao.setInt(4, minuto);
                psInsertSubstituicao.addBatch();
            }

            // Simular evento genérico
            String tipoEvento = rand.nextBoolean() ? "falta" : "escanteio";
            int jogadorId = rand.nextBoolean() ? partida.getSelecao1().getPlayers().get(rand.nextInt(partida.getSelecao1().getPlayers().size())).getId()
                    : partida.getSelecao2().getPlayers().get(rand.nextInt(partida.getSelecao2().getPlayers().size())).getId();
            System.out.println("Inserindo evento: partida_id=" + partida.getId() + ", jogador_id=" + jogadorId + ", tipo=" + tipoEvento + ", minuto=" + minuto); // Debug
            psInsertEvento.setString(1, tipoEvento);
            psInsertEvento.setInt(2, jogadorId);
            psInsertEvento.setInt(3, minuto);
            psInsertEvento.setInt(4, partida.getId());
            psInsertEvento.addBatch();
        }
    }
    private void atualizarEstatisticasGlobaisEquipe(Partida partida, PreparedStatement psUpdateEstatisticasEquipe, PreparedStatement psInsertEstatisticasEquipe) throws SQLException {
        Random rand = new Random();

        // Atualizar estatísticas para a seleção casa
        int remates = rand.nextInt(20);
        int livres = rand.nextInt(10);
        int forasDeJogo = rand.nextInt(5);

        // Verificar se já existe uma entrada para esta partida e seleção
        if (existeEstatisticaGlobalEquipe(partida.getId(), partida.getSelecao1().getId())) {
            // Atualizar estatísticas existentes
            psUpdateEstatisticasEquipe.setInt(1, remates);
            psUpdateEstatisticasEquipe.setInt(2, livres);
            psUpdateEstatisticasEquipe.setInt(3, forasDeJogo);
            psUpdateEstatisticasEquipe.setInt(4, partida.getId());
            psUpdateEstatisticasEquipe.setInt(5, partida.getSelecao1().getId());
            psUpdateEstatisticasEquipe.addBatch();
        } else {
            // Inserir novas estatísticas
            psInsertEstatisticasEquipe.setInt(1, partida.getId());
            psInsertEstatisticasEquipe.setInt(2, partida.getSelecao1().getId());
            psInsertEstatisticasEquipe.setInt(3, remates);
            psInsertEstatisticasEquipe.setInt(4, livres);
            psInsertEstatisticasEquipe.setInt(5, forasDeJogo);
            psInsertEstatisticasEquipe.addBatch();
        }

        // Atualizar estatísticas para a seleção fora
        remates = rand.nextInt(20);
        livres = rand.nextInt(10);
        forasDeJogo = rand.nextInt(5);

        // Verificar se já existe uma entrada para esta partida e seleção
        if (existeEstatisticaGlobalEquipe(partida.getId(), partida.getSelecao2().getId())) {
            // Atualizar estatísticas existentes
            psUpdateEstatisticasEquipe.setInt(1, remates);
            psUpdateEstatisticasEquipe.setInt(2, livres);
            psUpdateEstatisticasEquipe.setInt(3, forasDeJogo);
            psUpdateEstatisticasEquipe.setInt(4, partida.getId());
            psUpdateEstatisticasEquipe.setInt(5, partida.getSelecao2().getId());
            psUpdateEstatisticasEquipe.addBatch();
        } else {
            // Inserir novas estatísticas
            psInsertEstatisticasEquipe.setInt(1, partida.getId());
            psInsertEstatisticasEquipe.setInt(2, partida.getSelecao2().getId());
            psInsertEstatisticasEquipe.setInt(3, remates);
            psInsertEstatisticasEquipe.setInt(4, livres);
            psInsertEstatisticasEquipe.setInt(5, forasDeJogo);
            psInsertEstatisticasEquipe.addBatch();
        }

        // Executar batch para atualização e inserção de estatísticas globais da equipe
        psUpdateEstatisticasEquipe.executeBatch();
        psInsertEstatisticasEquipe.executeBatch();
    }

    // Verificar se existe uma entrada para estatísticas globais desta partida e seleção
    private boolean existeEstatisticaGlobalEquipe(int partidaId, int selecaoId) throws SQLException {
        String query = "SELECT COUNT(*) FROM estatisticas_globais_equipe WHERE partida_id = ? AND selecao_id = ?";
        try (PreparedStatement ps = conn.getConnection().prepareStatement(query)) {
            ps.setInt(1, partidaId);
            ps.setInt(2, selecaoId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                int count = rs.getInt(1);
                return count > 0;
            }
            return false;
        }
    }


    // Método para atualizar classificação do grupo
    private void atualizarClassificacao(Partida partida, PreparedStatement psUpdateClassificacao) throws SQLException {
        // Atualizar classificação para a seleção casa
        int pontosCasa = 0;
        int vitoriasCasa = 0;
        int empatesCasa = 0;
        int derrotasCasa = 0;
        if (partida.getGols1() > partida.getGols2()) {
            pontosCasa = 3;
            vitoriasCasa = 1;
        } else if (partida.getGols1() == partida.getGols2()) {
            pontosCasa = 1;
            empatesCasa = 1;
        } else {
            derrotasCasa = 1;
        }
        System.out.println("Atualizando classificação: selecao_id=" + partida.getSelecao1().getId() + ", grupo_id=" + partida.getGrupoId() + ", pontos=" + pontosCasa + ", vitorias=" + vitoriasCasa + ", empates=" + empatesCasa + ", derrotas=" + derrotasCasa + ", gols_pro=" + partida.getGols1() + ", gols_contra=" + partida.getGols2()); // Debug
        psUpdateClassificacao.setInt(1, pontosCasa);
        psUpdateClassificacao.setInt(2, vitoriasCasa);
        psUpdateClassificacao.setInt(3, empatesCasa);
        psUpdateClassificacao.setInt(4, derrotasCasa);
        psUpdateClassificacao.setInt(5, partida.getGols1());
        psUpdateClassificacao.setInt(6, partida.getGols2());
        psUpdateClassificacao.setInt(7, partida.getSelecao1().getId());
        psUpdateClassificacao.setInt(8, partida.getGrupoId());
        psUpdateClassificacao.addBatch();

        // Atualizar classificação para a seleção fora
        int pontosFora = 0;
        int vitoriasFora = 0;
        int empatesFora = 0;
        int derrotasFora = 0;
        if (partida.getGols2() > partida.getGols1()) {
            pontosFora = 3;
            vitoriasFora = 1;
        } else if (partida.getGols2() == partida.getGols1()) {
            pontosFora = 1;
            empatesFora = 1;
        } else {
            derrotasFora = 1;
        }
        System.out.println("Atualizando classificação: selecao_id=" + partida.getSelecao2().getId() + ", grupo_id=" + partida.getGrupoId() + ", pontos=" + pontosFora + ", vitorias=" + vitoriasFora + ", empates=" + empatesFora + ", derrotas=" + derrotasFora + ", gols_pro=" + partida.getGols2() + ", gols_contra=" + partida.getGols1()); // Debug
        psUpdateClassificacao.setInt(1, pontosFora);
        psUpdateClassificacao.setInt(2, vitoriasFora);
        psUpdateClassificacao.setInt(3, empatesFora);
        psUpdateClassificacao.setInt(4, derrotasFora);
        psUpdateClassificacao.setInt(5, partida.getGols2());
        psUpdateClassificacao.setInt(6, partida.getGols1());
        psUpdateClassificacao.setInt(7, partida.getSelecao2().getId());
        psUpdateClassificacao.setInt(8, partida.getGrupoId());
        psUpdateClassificacao.addBatch();
    }

    // Métodos para consultar informações

    // Consulta dados individuais de um jogador
    public List<EstatisticasIndividuais> consultarEstatisticasJogador(int jogadorId) throws SQLException {
        List<EstatisticasIndividuais> estatisticas = new ArrayList<>();
        String query = "SELECT * FROM estatisticas_individuais WHERE jogador_id = ?";
        try (PreparedStatement ps = conn.getConnection().prepareStatement(query)) {
            ps.setInt(1, jogadorId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                int partidaId = rs.getInt("partida_id");
                int passes = rs.getInt("passes");
                int assistencias = rs.getInt("assistencias");
                int remates = rs.getInt("remates");
                int minutosJogados = rs.getInt("minutos_jogados");
                EstatisticasIndividuais estatistica = new EstatisticasIndividuais(partidaId, jogadorId, passes, assistencias, remates, minutosJogados);
                estatisticas.add(estatistica);
            }
        }
        return estatisticas;
    }


    // Consulta dados de uma equipe
    public List<EstatisticasGlobaisEquipe> consultarEstatisticasEquipe(int selecaoId) throws SQLException {
        List<EstatisticasGlobaisEquipe> estatisticas = new ArrayList<>();
        String query = "SELECT * FROM estatisticas_globais_equipe WHERE selecao_id = ?";
        try (PreparedStatement ps = conn.getConnection().prepareStatement(query)) {
            ps.setInt(1, selecaoId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                int partidaId = rs.getInt("partida_id");
                int remates = rs.getInt("remates");
                int livres = rs.getInt("livres");
                int forasDeJogo = rs.getInt("foras_de_jogo");
                EstatisticasGlobaisEquipe estatistica = new EstatisticasGlobaisEquipe(partidaId, selecaoId, remates, livres, forasDeJogo);
                estatisticas.add(estatistica);
            }
        }
        return estatisticas;
    }

    // Consulta lista de melhores marcadores
    public List<MelhorMarcador> consultarMelhoresMarcadores() throws SQLException {
        List<MelhorMarcador> melhoresMarcadores = new ArrayList<>();
        String query = "SELECT jogador_id, COUNT(*) AS num_gols FROM golo GROUP BY jogador_id ORDER BY num_gols DESC";
        try (PreparedStatement ps = conn.getConnection().prepareStatement(query)) {
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                int jogadorId = rs.getInt("jogador_id");
                int numGols = rs.getInt("num_gols");
                MelhorMarcador marcador = new MelhorMarcador(jogadorId, numGols);
                melhoresMarcadores.add(marcador);
            }
        }
        return melhoresMarcadores;
    }
    public Partida buscarPartida(int id) {
        String sql = "SELECT DISTINCT p.id AS partida_id, p.gols_selecao1, p.gols_selecao2, p.selecao_casa_id , p.selecao_fora_id , " +
                "p.estatisticas_equipe1_id, p.estatisticas_equipe2_id " +
                "FROM partidas AS p " +
                "LEFT JOIN estatisticas_globais_equipe AS e1 ON p.estatisticas_equipe1_id = e1.id " +
                "LEFT JOIN estatisticas_globais_equipe AS e2 ON p.estatisticas_equipe2_id = e2.id " +
                "LEFT JOIN eventos AS ev ON ev.partida_id = p.id " +
                "WHERE p.id = ?";
        try (PreparedStatement pstmt = conn.getConnection().prepareStatement(sql)) {
            pstmt.setInt(1, id);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                Partida partida = new Partida();
                partida.setId(rs.getInt("partida_id"));
                partida.setGols1(rs.getInt("gols_selecao1"));
                partida.setGols2(rs.getInt("gols_selecao2"));

                // Carregar seleções
                Selecao selecao1 = new Selecao();
                selecao1.setId(rs.getInt("selecao_casa_id"));
                partida.setSelecao1(selecao1);

                Selecao selecao2 = new Selecao();
                selecao2.setId(rs.getInt("selecao_fora_id"));
                partida.setSelecao2(selecao2);

//                // Carregar estatísticas globais das equipes
//                EstatisticasGlobaisEquipe estatisticasEquipe1 = new EstatisticasGlobaisEquipe();
//                estatisticasEquipe1.setId(rs.getInt("e1.id"));
//                // Preencher outras estatísticas conforme necessário
//
//                EstatisticasGlobaisEquipe estatisticasEquipe2 = new EstatisticasGlobaisEquipe();
//                estatisticasEquipe2.setId(rs.getInt("e2.id"));
//                // Preencher outras estatísticas conforme necessário
//
//                partida.setEstatisticasEquipe1(estatisticasEquipe1);
//                partida.setEstatisticasEquipe2(estatisticasEquipe2);

                // Carregar outros detalhes da partida (substituições, gols, cartões, etc.)

                return partida;
            } else {
                return null;
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public void deletarPartida(int id) {
        String sql = "DELETE FROM partidas WHERE id = ?";
        try (PreparedStatement pstmt = conn.getConnection().prepareStatement(sql)) {
            pstmt.setInt(1, id);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public int getId(int id) {
        String sql = "SELECT id FROM partidas WHERE id = ?";
        try (PreparedStatement pstmt = conn.getConnection().prepareStatement(sql)) {
            pstmt.setInt(1, id);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt("id");  // Pega o ID do resultado
                } else {
                    return -1;  // Indica que o nome não foi encontrado
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
}
