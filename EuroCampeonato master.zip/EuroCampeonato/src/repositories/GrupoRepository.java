package repositories;

import config.Database;
import entities.Grupo;
import entities.Player;
import entities.Selecao;
import entities.SelecaoGrupo;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class GrupoRepository {
    private final Database conn;

    public GrupoRepository(Database conn) {
        this.conn = conn;
    }

    public void createGrupo(Grupo grupo) {
        String sql = "INSERT INTO grupos (nome) VALUES (?)";
        try (PreparedStatement pstmt = conn.getConnection().prepareStatement(sql)) {
            pstmt.setString(1, grupo.getNome());
            pstmt.executeUpdate();
            System.out.println("Criado com sucesso!");
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }


    public List<Grupo> getTodosGrupos() {
        List<Grupo> grupos = new ArrayList<>();
        String query = "SELECT * FROM grupos";
        try (PreparedStatement stmt = conn.getConnection().prepareStatement(query);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                int grupoId = rs.getInt("id");
                String nome = rs.getString("nome");
                List<SelecaoGrupo> selecoes = getSelecoesPorGrupo(grupoId);
                Grupo grupo = new Grupo(grupoId, nome, selecoes);
                grupos.add(grupo);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return grupos;
    }

    public List<SelecaoGrupo> getSelecoesPorGrupo(int grupoId) {
        List<SelecaoGrupo> selecoes = new ArrayList<>();
        String query = "SELECT sg.id, sg.grupo_id, sg.selecao_id, sg.pontos, sg.jogos, sg.vitorias, sg.empates, sg.derrotas, sg.gols_pro, sg.gols_contra, s.nome " +
                "FROM selecao_grupo sg " +
                "JOIN selecoes s ON sg.selecao_id = s.id " +
                "WHERE sg.grupo_id = ?";
        try (PreparedStatement stmt = conn.getConnection().prepareStatement(query)) {
            stmt.setInt(1, grupoId);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Selecao selecao = new Selecao(rs.getInt("selecao_id"), rs.getString("nome"));
                SelecaoGrupo selecaoGrupo = new SelecaoGrupo(
                        rs.getInt("id"),
                        rs.getInt("grupo_id"),
                        selecao,
                        rs.getInt("pontos"),
                        rs.getInt("jogos"),
                        rs.getInt("vitorias"),
                        rs.getInt("empates"),
                        rs.getInt("derrotas"),
                        rs.getInt("gols_pro"),
                        rs.getInt("gols_contra")
                );
                selecoes.add(selecaoGrupo);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return selecoes;
    }

    public void mostrarGruposESelecoes() {
        String query = "SELECT g.nome AS grupo, s.nome AS selecao " +
                "FROM selecao_grupo sg " +
                "JOIN grupos g ON sg.grupo_id = g.id " +
                "JOIN selecoes s ON sg.selecao_id = s.id " +
                "ORDER BY g.nome, s.nome";
        try (PreparedStatement stmt = conn.getConnection().prepareStatement(query);
             ResultSet rs = stmt.executeQuery()) {

            String currentGroup = "";
            while (rs.next()) {
                String grupo = rs.getString("grupo");
                String selecao = rs.getString("selecao");

                if (!grupo.equals(currentGroup)) {
                    currentGroup = grupo;
                    System.out.println("Grupo " + grupo + ":");
                }
                System.out.println("  " + selecao);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void imprimirSelecoesPorGrupo(int grupoId) {
        List<SelecaoGrupo> selecoes = getSelecoesPorGrupo(grupoId);
        System.out.println("Seleções do Grupo " + grupoId + ":");
        for (SelecaoGrupo sg : selecoes) {
            System.out.println("ID: " + sg.getId());
            System.out.println("Seleção: " + sg.getSelecao().getNome());
            System.out.println("Pontos: " + sg.getPontos());
            System.out.println("Jogos: " + sg.getJogos());
            System.out.println("Vitórias: " + sg.getVitorias());
            System.out.println("Empates: " + sg.getEmpates());
            System.out.println("Derrotas: " + sg.getDerrotas());
            System.out.println("Gols Pró: " + sg.getGolsPro());
            System.out.println("Gols Contra: " + sg.getGolsContra());
            System.out.println();
        }
    }
    public void mostrarClassificacaoGrupos() {
        String query = "SELECT g.id, g.nome " +
                "FROM grupos g";
        try (PreparedStatement stmt = conn.getConnection().prepareStatement(query)) {
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                int grupoId = rs.getInt("id");
                String nomeGrupo = rs.getString("nome");

                List<SelecaoGrupo> selecoes = getSelecoesPorGrupo(grupoId);
                // Ordenar seleções pelo número de pontos, saldo de gols, etc.
                Collections.sort(selecoes, new Comparator<SelecaoGrupo>() {
                    @Override
                    public int compare(SelecaoGrupo sg1, SelecaoGrupo sg2) {
                        // Comparar pelo número de pontos
                        int comparePontos = Integer.compare(sg2.getPontos(), sg1.getPontos());
                        if (comparePontos != 0) {
                            return comparePontos;
                        }

                        // Comparar pelo saldo de gols (gols pró - gols contra)
                        int saldoGols1 = sg1.getGolsPro() - sg1.getGolsContra();
                        int saldoGols2 = sg2.getGolsPro() - sg2.getGolsContra();
                        int compareSaldoGols = Integer.compare(saldoGols2, saldoGols1);
                        if (compareSaldoGols != 0) {
                            return compareSaldoGols;
                        }

                        // Comparar pelo número de gols pró
                        int compareGolsPro = Integer.compare(sg2.getGolsPro(), sg1.getGolsPro());
                        if (compareGolsPro != 0) {
                            return compareGolsPro;
                        }

                        // Caso de igualdade, ordenar alfabeticamente pelo nome da seleção
                        return sg1.getSelecao().getNome().compareTo(sg2.getSelecao().getNome());
                    }
                });

                // Imprimir classificação do grupo
                System.out.println("Classificação do Grupo " + nomeGrupo + ":");
                for (int i = 0; i < selecoes.size(); i++) {
                    SelecaoGrupo sg = selecoes.get(i);
                    System.out.printf("%d. %s - Pontos: %d, Jogos: %d, Vitórias: %d, Empates: %d, Derrotas: %d, Gols Pró: %d, Gols Contra: %d%n",
                            i + 1,
                            sg.getSelecao().getNome(),
                            sg.getPontos(),
                            sg.getJogos(),
                            sg.getVitorias(),
                            sg.getEmpates(),
                            sg.getDerrotas(),
                            sg.getGolsPro(),
                            sg.getGolsContra());
                }
                System.out.println(); // Adicionar linha em branco entre os grupos
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public int getIdByName(String nome) {
        String sql = "SELECT id FROM grupos WHERE nome = ?";
        try (PreparedStatement pstmt = conn.getConnection().prepareStatement(sql)) {
            pstmt.setString(1, nome);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt("id");  // Pega o ID do resultado
                } else {
                    return -1;  // Indica que o nome não foi encontrado
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public void mostrar2ClassificacaoGrupos() {
        String query = "SELECT g.id, g.nome FROM grupos g";
        try (PreparedStatement stmt = conn.getConnection().prepareStatement(query)) {
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                int grupoId = rs.getInt("id");
                String nomeGrupo = rs.getString("nome");
                List<SelecaoGrupo> selecoes = getSelecoesPorGrupo(grupoId);
                // Ordenar seleções pelo número de pontos, saldo de gols, etc.
                Collections.sort(selecoes, new Comparator<SelecaoGrupo>() {
                    @Override
                    public int compare(SelecaoGrupo sg1, SelecaoGrupo sg2) {
                        // Comparar pelo número de pontos
                        int comparePontos = Integer.compare(sg2.getPontos(), sg1.getPontos());
                        if (comparePontos != 0) {
                            return comparePontos;
                        }

                        // Comparar pelo saldo de gols (gols pró - gols contra)
                        int saldoGols1 = sg1.getGolsPro() - sg1.getGolsContra();
                        int saldoGols2 = sg2.getGolsPro() - sg2.getGolsContra();
                        int compareSaldoGols = Integer.compare(saldoGols2, saldoGols1);
                        if (compareSaldoGols != 0) {
                            return compareSaldoGols;
                        }
                        // Comparar pelo número de gols pró
                        int compareGolsPro = Integer.compare(sg2.getGolsPro(), sg1.getGolsPro());
                        if (compareGolsPro != 0) {
                            return compareGolsPro;
                        }

                        // Caso de igualdade, ordenar alfabeticamente pelo nome da seleção
                        return sg1.getSelecao().getNome().compareTo(sg2.getSelecao().getNome());
                    }
                });
                // Imprimir os dois primeiros classificados do grupo
                System.out.println("Equipas Qualificadas -  Grupo " + nomeGrupo + ":");
                for (int i = 0; i < Math.min(selecoes.size(), 2); i++) {  // Apenas os 2 primeiros
                    SelecaoGrupo sg = selecoes.get(i);
                    System.out.printf("%d. %s - Pontos: %d, Jogos: %d, Vitórias: %d, Empates: %d, Derrotas: %d, Gols Pró: %d, Gols Contra: %d%n",
                            i + 1,
                            sg.getSelecao().getNome(),
                            sg.getPontos(),
                            sg.getJogos(),
                            sg.getVitorias(),
                            sg.getEmpates(),
                            sg.getDerrotas(),
                            sg.getGolsPro(),
                            sg.getGolsContra());
                }
                System.out.println(); // Adicionar linha em branco entre os grupos
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public Grupo getGrupor(int id) {
        String sql = "SELECT * FROM grupos WHERE id = ?";
        try (PreparedStatement pstmt = conn.getConnection().prepareStatement(sql)) {
            pstmt.setLong(1, id);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                Grupo grupo = new Grupo();
                grupo.setId(rs.getInt("id"));
                grupo.setNome(rs.getString("nome"));
                return grupo;
            } else {
                return null;
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }


}
