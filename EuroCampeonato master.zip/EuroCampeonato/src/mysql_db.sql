CREATE DATABASE euro_campeonato;
USE euro_campeonato;

CREATE TABLE paises (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(255) NOT NULL
);

CREATE TABLE cidades (
     id INT AUTO_INCREMENT PRIMARY KEY,
     nome VARCHAR(255) NOT NULL,
     pais_id INT,
     FOREIGN KEY (pais_id) REFERENCES paises(id)
);

CREATE TABLE estadios (
      id INT AUTO_INCREMENT PRIMARY KEY,
      nome VARCHAR(255) NOT NULL,
      cidade_id INT,
      capacidade INT,
      FOREIGN KEY (cidade_id) REFERENCES cidades(id)
);

CREATE TABLE selecoes (
      id INT AUTO_INCREMENT PRIMARY KEY,
      nome VARCHAR(255) NOT NULL,
      pais_id INT,
      FOREIGN KEY (pais_id) REFERENCES paises(id)
);

CREATE TABLE jogadores (
       id INT AUTO_INCREMENT PRIMARY KEY,
       nome VARCHAR(255) NOT NULL,
       idade INT,
       posicao VARCHAR(255),
       selecao_id INT,
       FOREIGN KEY (selecao_id) REFERENCES selecoes(id)
);

CREATE TABLE partidas (
      id INT PRIMARY KEY AUTO_INCREMENT,
      gols_selecao1 INT,
      gols_selecao2 INT,
      estatisticas_equipe1_id INT,
      estatisticas_equipe2_id INT,
      selecao_casa_id INT,
      selecao_fora_id INT,
      estadio_id INT,
      data_hora DATETIME,
      FOREIGN KEY (selecao_casa_id) REFERENCES selecoes(id),
      FOREIGN KEY (selecao_fora_id) REFERENCES selecoes(id),
      FOREIGN KEY (estadio_id) REFERENCES estadios(id),
      FOREIGN KEY (estatisticas_equipe1_id) REFERENCES EstatisticasGlobaisEquipe(id),
      FOREIGN KEY (estatisticas_equipe2_id) REFERENCES EstatisticasGlobaisEquipe(id)
);

CREATE TABLE eventos (
     id INT AUTO_INCREMENT PRIMARY KEY,
     tipo VARCHAR(255),
     jogador_id INT,
     minuto INT,
     partida_id INT,
     FOREIGN KEY (jogador_id) REFERENCES jogadores(id),
     FOREIGN KEY (partida_id) REFERENCES partidas(id)
);

CREATE TABLE grupos (
    id INT PRIMARY KEY AUTO_INCREMENT,
    nome VARCHAR(1) NOT NULL
);

CREATE TABLE selecao_grupo (
   id INT PRIMARY KEY AUTO_INCREMENT,
   grupo_id INT NOT NULL,
   selecao_id INT NOT NULL,
   pontos INT DEFAULT 0,
   jogos INT DEFAULT 0,
   vitorias INT DEFAULT 0,
   empates INT DEFAULT 0,
   derrotas INT DEFAULT 0,
   gols_pro INT DEFAULT 0,
   gols_contra INT DEFAULT 0,
   FOREIGN KEY (grupo_id) REFERENCES grupos(id),
   FOREIGN KEY (selecao_id) REFERENCES selecoes(id)
);


-- Tabela Substituicao
CREATE TABLE Substituicao (
id INT PRIMARY KEY AUTO_INCREMENT,
partida_id INT NOT NULL,
jogador_sai_id INT NOT NULL,
jogador_entra_id INT NOT NULL,
minuto INT,
FOREIGN KEY (partida_id) REFERENCES Partida(id),
FOREIGN KEY (jogador_sai_id) REFERENCES Jogador(id),
FOREIGN KEY (jogador_entra_id) REFERENCES Jogador(id)
);

-- Tabela Golo
CREATE TABLE Golo (
id INT PRIMARY KEY AUTO_INCREMENT,
partida_id INT NOT NULL,
jogador_id INT NOT NULL,
minuto INT,
FOREIGN KEY (partida_id) REFERENCES Partida(id),
FOREIGN KEY (jogador_id) REFERENCES Jogador(id)
);

-- Tabela Cartao
CREATE TABLE Cartao (
id INT PRIMARY KEY AUTO_INCREMENT,
partida_id INT NOT NULL,
jogador_id INT NOT NULL,
tipo VARCHAR(10), -- 'amarelo' ou 'vermelho'
minuto INT,
FOREIGN KEY (partida_id) REFERENCES Partida(id),
FOREIGN KEY (jogador_id) REFERENCES Jogador(id)
);

-- Tabela EstatisticasGlobaisEquipe
CREATE TABLE EstatisticasGlobaisEquipe (
   id INT PRIMARY KEY AUTO_INCREMENT,
   partida_id INT NOT NULL,
   selecao_id INT NOT NULL,
   remates INT,
   livres INT,
   foras_de_jogo INT,
   FOREIGN KEY (partida_id) REFERENCES Partida(id),
   FOREIGN KEY (selecao_id) REFERENCES Selecao(id)
);

-- Tabela EstatisticasIndividuais
CREATE TABLE EstatisticasIndividuais (
 id INT PRIMARY KEY AUTO_INCREMENT,
 partida_id INT NOT NULL,
 jogador_id INT NOT NULL,
 passes INT,
 assistencias INT,
 remates INT,
 minutos_jogados INT,
 FOREIGN KEY (partida_id) REFERENCES Partida(id),
 FOREIGN KEY (jogador_id) REFERENCES Jogador(id)
);
