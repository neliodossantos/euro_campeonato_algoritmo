package entities;
public class Gol extends Event{
    private int partidaId;
    private Player jogador;
    private int minuto;
    public Gol(int partidaId, Player jogador, int minuto) {
        super();
        this.partidaId = partidaId;
        this.jogador = jogador;
        this.minuto = minuto;
    }

    public int getPartidaId() {
        return partidaId;
    }

    public void setPartidaId(int partidaId) {
        this.partidaId = partidaId;
    }

    public Player getJogador() {
        return jogador;
    }

    public void setJogador(Player jogador) {
        this.jogador = jogador;
    }

    public int getMinuto() {
        return minuto;
    }

    public void setMinuto(int minuto) {
        this.minuto = minuto;
    }
}
