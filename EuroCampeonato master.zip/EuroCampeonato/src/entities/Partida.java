package entities;

import java.util.ArrayList;
import java.util.List;

public class Partida {
    private int Id;
    private Selecao selecao1;
    private Selecao selecao2;
    private int gols1;
    private int gols2;
    private List<EstatisticasPartida> estatisticas;
    private List<Substituicao> substituicoes;
    private List<Gol> golos;
    private List<Cartao> cartoes;
    private EstatisticasGlobaisEquipe estatisticasEquipe1;
    private EstatisticasGlobaisEquipe estatisticasEquipe2;
    private int estadio_id;
    private int grupoId;

    private List<Event> eventos;


    public Partida(){};

    public Partida(Selecao selecao1, Selecao selecao2) {
        this.selecao1 = selecao1;
        this.selecao2 = selecao2;
        this.estatisticas = new ArrayList<>();
        this.substituicoes = new ArrayList<>();
        this.golos = new ArrayList<>();
        this.cartoes = new ArrayList<>();
        this.eventos = new ArrayList<>();
    }
    public Partida(Selecao selecao1, Selecao selecao2, int gols1, int gols2) {
        this.selecao1 = selecao1;
        this.selecao2 = selecao2;
        this.gols1 = gols1;
        this.gols2 = gols2;
        this.estatisticas = new ArrayList<>();
        this.substituicoes = new ArrayList<>();
        this.golos = new ArrayList<>();
        this.cartoes = new ArrayList<>();
    }

    public Partida(Selecao selecaoCasa, Selecao selecaoFora, int estadioId) {
        this.selecao1  = selecaoCasa;
        this.selecao2 = selecaoFora;
        this.estadio_id = estadioId;
    }

    // Getters e setters
    public Selecao getSelecao1() {
        return selecao1;
    }

    public Selecao getSelecao2() {
        return selecao2;
    }

    public int getGols1() {
        return gols1;
    }

    public int getGols2() {
        return gols2;
    }

    public List<EstatisticasPartida> getEstatisticas() {
        return estatisticas;
    }

    public void addEstatistica(EstatisticasPartida estatistica) {
        this.estatisticas.add(estatistica);
    }

    public void addSubstituicao(Substituicao substituicao) {
        this.substituicoes.add(substituicao);
    }

    public void addGolo(Gol golo) {
        this.golos.add(golo);
    }

    public void addCartao(Cartao cartao) {
        this.cartoes.add(cartao);
    }

    public EstatisticasGlobaisEquipe getEstatisticasEquipe1() {
        return estatisticasEquipe1;
    }

    public void setEstatisticasEquipe1(EstatisticasGlobaisEquipe estatisticasEquipe1) {
        this.estatisticasEquipe1 = estatisticasEquipe1;
    }

    public EstatisticasGlobaisEquipe getEstatisticasEquipe2() {
        return estatisticasEquipe2;
    }

    public void setEstatisticasEquipe2(EstatisticasGlobaisEquipe estatisticasEquipe2) {
        this.estatisticasEquipe2 = estatisticasEquipe2;
    }

    public List<Substituicao> getSubstituicoes() {
        return substituicoes;
    }

    public List<Gol> getGolos() {
        return golos;
    }

    public List<Cartao> getCartoes() {
        return cartoes;
    }

    public int getId() {
        return Id;
    }

    public void setId(int id) {
        Id = id;
    }

    public void setGols1(int gols1) {
        this.gols1 = gols1;
    }
    public void setGols2(int gols2) {
        this.gols2 = gols2;
    }

    public void setSelecao1(Selecao selecao1) {
        this.selecao1 = selecao1;
    }

    public void setSelecao2(Selecao selecao2) {
        this.selecao2 = selecao2;
    }

    public int getEstadio_id() {
        return estadio_id;
    }

    public void setEstadio_id(int estadio_id) {
        this.estadio_id = estadio_id;
    }

    public int getGrupoId() {
        return grupoId;
    }

    public void setGrupoId(int grupoId) {
        this.grupoId = grupoId;
    }

    public List<Event> getEventos() {
        return eventos;
    }

    public void adicionarEvento(Event evento) {
        eventos.add(evento);
    }

    @Override
    public String toString() {
        return "Partida{" +
                "id=" + this.Id +
                ", selecao1=" + selecao1 +
                ", selecao2=" + selecao2 +
                ", gols1=" + gols1 +
                ", gols2=" + gols2 +
                ", eventos=" + eventos +
                '}';
    }
}
