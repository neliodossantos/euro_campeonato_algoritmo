package entities;

public class Cartao {
}
