package entities;
public abstract class Event {
    protected int id;
    protected int partidaId;
    protected int minuto;

    public Event(){};
    public Event(int partidaId, int minuto) {
        this.partidaId = partidaId;
        this.minuto = minuto;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getPartidaId() {
        return partidaId;
    }

    public void setPartidaId(int partidaId) {
        this.partidaId = partidaId;
    }

    public int getMinuto() {
        return minuto;
    }

    public void setMinuto(int minuto) {
        this.minuto = minuto;
    }
}
