package entities;

public class SelecaoGrupo {
    private int id;
    private int grupoId;
    private Selecao selecao;
    private int pontos;
    private int jogos;
    private int vitorias;
    private int empates;
    private int derrotas;
    private int golsPro;
    private int golsContra;

    // Construtor
    public SelecaoGrupo(int id, int grupoId, Selecao selecao, int pontos, int jogos, int vitorias, int empates, int derrotas, int golsPro, int golsContra) {
        this.id = id;
        this.grupoId = grupoId;
        this.selecao = selecao;
        this.pontos = pontos;
        this.jogos = jogos;
        this.vitorias = vitorias;
        this.empates = empates;
        this.derrotas = derrotas;
        this.golsPro = golsPro;
        this.golsContra = golsContra;
    }

    // Getters e setters
    public int getId() {
        return id;
    }

    public int getGrupoId() {
        return grupoId;
    }

    public Selecao getSelecao() {
        return selecao;
    }

    public int getPontos() {
        return pontos;
    }

    public int getJogos() {
        return jogos;
    }

    public int getVitorias() {
        return vitorias;
    }

    public int getEmpates() {
        return empates;
    }

    public int getDerrotas() {
        return derrotas;
    }

    public int getGolsPro() {
        return golsPro;
    }

    public int getGolsContra() {
        return golsContra;
    }

    public void adicionarVitoria() {
        vitorias++;
        pontos += 3;
        jogos++;
    }

    public void adicionarEmpate() {
        empates++;
        pontos += 1;
        jogos++;
    }

    public void adicionarDerrota() {
        derrotas++;
        jogos++;
    }

    public void adicionarGolsPro(int gols) {
        golsPro += gols;
    }

    public void adicionarGolsContra(int gols) {
        golsContra += gols;
    }
}
