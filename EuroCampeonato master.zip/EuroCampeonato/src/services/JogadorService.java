package services;
import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;

import entities.EstatisticasIndividuais;
import entities.MelhorMarcador;
import entities.Player;
import entities.Selecao;
import repositories.JogadorRepository;
import repositories.PartidaRepository;
import repositories.SelecaoRepository;


public class JogadorService {

    private final JogadorRepository jogadorRepository;
    private final SelecaoRepository selecaoRepository;
    private final PartidaRepository partidaRepository;

    public JogadorService(JogadorRepository jogadorRepository, SelecaoRepository selecaoRepository, PartidaRepository partidaRepository)
    {
        this.jogadorRepository = jogadorRepository;
        this.selecaoRepository = selecaoRepository;
        this.partidaRepository= partidaRepository;
    }
    public void criarJogador(Scanner scanner){
        System.out.println("Digite o nome da selecao: ");
        String nome_selecao = scanner.next();
        int getSelecaoID = selecaoRepository.getIdByName(nome_selecao);
        if(getSelecaoID > 0){
            System.out.println("Digite o nome do jogador: ");
            String nome_jogador = scanner.next();
            System.out.println("Digite a idade do jogador: ");
            int idade = scanner.nextInt();
            System.out.println("Digite a posicao: ");
            String posicao = scanner.next();
            Player jogador = new Player();
            jogador.setNome(nome_jogador);
            jogador.setIdade(idade);
            jogador.setPosicao(posicao);
            Selecao getSelecao = selecaoRepository.getById(getSelecaoID);
            jogador.setTeam(getSelecao);
            jogadorRepository.createJogador(jogador);
        }else{
            System.out.println("Não encontrou a seleção, não é possivel criar o jogadores");
        }
    }
    public void listarMelhoresMarcadores() throws SQLException {
        List<MelhorMarcador> melhoresMarcadores = partidaRepository.consultarMelhoresMarcadores();
        for (MelhorMarcador melhorMarcador : melhoresMarcadores){
            Player jogador = jogadorRepository.getPlayer(melhorMarcador.getJogadorId());
            System.out.println(jogador.getNome()  + " golos: " + melhorMarcador.getNumGols());
        }
    }

    public void imprimirEstatisticasJogador(Scanner scanner) throws SQLException {
        System.out.println("Digite o nome do Jogador:");
        String nome  = scanner.next();
        scanner.nextLine();

        int getJogadorID = jogadorRepository.getIdByName(nome);

        if(getJogadorID > 0 ){
           List<EstatisticasIndividuais> estatisticasIndividuais =  partidaRepository.consultarEstatisticasJogador(getJogadorID);
           Player jogador = jogadorRepository.getPlayer(getJogadorID);
           if(!estatisticasIndividuais.isEmpty()){
               for (EstatisticasIndividuais estatistica : estatisticasIndividuais){
                   System.out.println("Posicao" + jogador.getPosicao());
                   System.out.println("Numero de Assistencias: " + estatistica.getAssistencias());
                   System.out.println("Numero de passes: " + estatistica.getPasses());
                   System.out.println("Minutos em jogos: " + estatistica.getMinutosJogados());
                   System.out.println("Numero de Remates: " + estatistica.getRemates());
               }
           }else{
               System.out.println("Numero de Assistencias: " + 0);
               System.out.println("Numero de passes: " + 0);
               System.out.println("Minutos em jogos: " + 0);
               System.out.println("Numero de Remates: " + 0);
           }
        }else{
            System.out.println("Não encontrou o jogador");
        }
    }
}