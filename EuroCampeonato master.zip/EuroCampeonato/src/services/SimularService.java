package services;
import config.Database;
import entities.Grupo;
import entities.SelecaoGrupo;
import entities.Partida;
import repositories.GrupoRepository;
import repositories.JogadorRepository;
import repositories.PartidaRepository;
import java.sql.SQLException;
import java.util.List;

public class SimularService {
    private Database database;
    private GrupoRepository grupoRepository;
    private PartidaRepository partidaRepository;
    private JogadorRepository jogadorRepository;
    private PartidaService partidaService;

    public SimularService(Database database, GrupoRepository grupoRepository,
                        PartidaRepository partidaRepository, JogadorRepository jogadorRepository,
                        PartidaService partidaService) {
        this.database = database;
        this.grupoRepository = grupoRepository;
        this.partidaRepository = partidaRepository;
        this.jogadorRepository = jogadorRepository;
        this.partidaService = partidaService;
    }

    public void simular() {
        try {
            List<Grupo> grupos = grupoRepository.getTodosGrupos();

            for (Grupo grupo : grupos) {
                List<SelecaoGrupo> selecoesGrupos = grupoRepository.getSelecoesPorGrupo(grupo.getId());
                int estadioId = 1;
                // Gerar partidas para o grupo
                List<Partida> partidas = partidaService.generatePartidas(selecoesGrupos, estadioId);

                // Inserir partidas no banco de dados
                partidaRepository.insertPartidas(partidas);

                // Simular resultados das partidas
                partidaRepository.simularPartidas(partidas);
            }

            // Mostrar classificação dos grupos
            grupoRepository.mostrarClassificacaoGrupos();

        } catch (SQLException e) {
            e.printStackTrace();
        }
//        finally {
//            try {
////                database.close();
//            } catch (SQLException e) {
//                e.printStackTrace();
//            }
//        }
    }
}

