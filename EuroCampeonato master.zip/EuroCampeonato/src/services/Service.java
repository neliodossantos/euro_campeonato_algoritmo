package services;
import config.Database;
import repositories.*;


public class Service {
    public final SelecaoRepository selecaoRepository;
    public final JogadorRepository jogadorRepository;
    public final PaisRepository paisRepository;
    public final PartidaRepository partidaRepository;
    public  final CidadeRepository cidadeRepository;
    public final EstadioRepository estadioRepository;
    public final GrupoRepository grupoRepository;
    public final SelecaoGrupoRepository selecaoGrupoRepository;
    public final CidadeService cidadeService;
    public final EstadioService estadioService;
    public final GrupoService grupoService;
    public final PaisService paisService;
    public final PartidaService partidaService;
    public final SelecaoService selecaoService;
    public final JogadorService jogadorService;
    public final SimularService simularService;

    public Service(Database db){
        this.grupoRepository = new GrupoRepository(db);
        this.selecaoRepository = new SelecaoRepository(db);
        this.jogadorRepository = new JogadorRepository(db);
        this.cidadeRepository = new CidadeRepository(db);
        this.estadioRepository = new EstadioRepository(db);
        this.paisRepository = new PaisRepository(db);
        this.partidaRepository = new PartidaRepository(db);
        this.selecaoGrupoRepository = new SelecaoGrupoRepository(db);
        this.selecaoService = new SelecaoService(paisRepository,partidaRepository,selecaoRepository , jogadorRepository ,selecaoGrupoRepository,grupoRepository);
        this.grupoService  = new GrupoService(grupoRepository);
        this.jogadorService = new JogadorService(jogadorRepository,selecaoRepository,partidaRepository);
        this.paisService = new PaisService(paisRepository);
        this.estadioService = new EstadioService(cidadeRepository,estadioRepository);
        this.cidadeService = new CidadeService(cidadeRepository,paisRepository,selecaoRepository);
        this.partidaService = new PartidaService(db,jogadorRepository,selecaoRepository,partidaRepository);
        this.simularService = new SimularService(db,grupoRepository,partidaRepository,jogadorRepository,partidaService);
    }



}
