package services;
import entities.Cidade;
import entities.Pais;
import repositories.CidadeRepository;
import repositories.PaisRepository;
import repositories.SelecaoRepository;
import java.util.List;
import java.util.Scanner;
public class CidadeService {
    private final CidadeRepository cidadeRepository;
    private final PaisRepository paisRepository;
    private final SelecaoRepository selecaoRepository;
    public CidadeService(CidadeRepository cidadeRepository ,
                         PaisRepository paisRepository , SelecaoRepository selecaoRepository){
        this.cidadeRepository = cidadeRepository;
        this.paisRepository = paisRepository;
        this.selecaoRepository = selecaoRepository;
    }
    public void criarCidade(Scanner scanner){
        System.out.println("Digite o nome do pais: ");
        String nome_pais = scanner.next();
        int getPaisID = paisRepository.getIdByName(nome_pais);
        if(getPaisID > 0){
            System.out.println("Digite o nome da cidade: ");
            String nome_selecao = scanner.next();
            Cidade cidade = new Cidade();
            Pais pais = new Pais();
            cidade.setNome(nome_selecao);
            pais  = paisRepository.getById(getPaisID);
            cidade.setPais(pais);
            cidadeRepository.createCidade(cidade);
        }else{
            System.out.println("Não encontrou o pais, não é possivel criar cidade");
        }
    }
    public void listarCidade(Scanner scanner){
        System.out.println("Digite o nome do pais: ");
        String nome_pais = scanner.next();
        int getSelecaoID = selecaoRepository.getIdByName(nome_pais);
        if(getSelecaoID > 0 ){
            List<Cidade> cidades =  cidadeRepository.getAllCidadesByPais(getSelecaoID);
            for(Cidade cidade : cidades){
                System.out.println("Nome: " + cidade.getNome());
            }
        }else{
            System.out.println("Não encontrou a seleção.");
        }
    }
}
