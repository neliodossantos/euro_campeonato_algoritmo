package services;
import entities.*;
import repositories.*;

import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;

public class SelecaoService {
    private final  SelecaoRepository selecaoRepository;
    private final PaisRepository paisRepository;
    private final PartidaRepository partidaRepository;
    private final JogadorRepository jogadorRepository;
    private final GrupoRepository grupoRepository;
    private final SelecaoGrupoRepository selecaoGrupoRepository;

    public SelecaoService(PaisRepository paisRepository , PartidaRepository partidaRepository,
                          SelecaoRepository selecaoRepository, JogadorRepository jogadorRepository,
                          SelecaoGrupoRepository selecaoGrupoRepository , GrupoRepository grupoRepository
    ){
        this.selecaoRepository = selecaoRepository;
        this.paisRepository = paisRepository;
        this.jogadorRepository = jogadorRepository;
        this.partidaRepository = partidaRepository;
        this.selecaoGrupoRepository  = selecaoGrupoRepository;
        this.grupoRepository = grupoRepository;
    }

    public void criarSelecao(Scanner scanner){
        System.out.println("Digite o nome do pais: ");
        String nome_pais = scanner.next();
        int getPaisID = paisRepository.getIdByName(nome_pais);
        if(getPaisID > 0){
            System.out.println("Digite o nome da selecao: ");
            String nome_selecao = scanner.next();
            Selecao selecao = new Selecao();
            selecao.setNome(nome_selecao);
            Pais pais  = paisRepository.getById(getPaisID);
            selecao.setCountry(pais);
            selecaoRepository.createSelecao(selecao);
        }else{
            System.out.println("Não encontrou o pais, não é possivel criar equipe");
        }
    }

    public void listarSelecao(Scanner scanner){
        List<Selecao> selecaos = selecaoRepository.getAllSelecao();
        for (Selecao selecao : selecaos){
            System.out.println(selecao.getNome());
        }
    }

    public void listarJogadoresSelecao(Scanner scanner){
        System.out.println("Digite o nome da Equipa:");
        String nome_equipa = scanner.next();
        int getEquipaID = selecaoRepository.getIdByName(nome_equipa);

        if(getEquipaID > 0){
            jogadorRepository.listarJogadoresEquipe(nome_equipa);
        }else{
            System.out.println("Não encontrou a selecao");
        }
    }
    public void imprimirEstatisticaSelecao(Scanner scanner){
        System.out.println("Digite a selecao: ");
        String nome  = scanner.next();

        int getSelecaoID =  selecaoRepository.getIdByName(nome);


        if(getSelecaoID > 0){
            SelecaoGrupo selecaoGrupo = selecaoGrupoRepository.getBySelecaoId(getSelecaoID);
            Grupo grupo = grupoRepository.getGrupor(selecaoGrupo.getGrupoId());
            selecaoRepository.consultarEstatisticasEquipe(grupo,selecaoGrupo);
        }else{
            System.out.println("Nao encontrou.");
        }

    }
}
