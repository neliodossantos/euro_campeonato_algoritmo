package services;

import entities.Pais;
import repositories.PaisRepository;

import java.util.List;
import java.util.Scanner;

public class PaisService {

    private final PaisRepository paisRepository;

    public PaisService(PaisRepository paisRepository){
        this.paisRepository = paisRepository;
    }
    public void criarPais(Scanner scanner){
        System.out.println("Digite o nome do pais: ");
        String nome_pais = scanner.next();
        Pais pais = new Pais();
        pais.setNome(nome_pais);
        paisRepository.createPais(pais);
    }

    public void listarPais(Scanner scanner){
        List<Pais> paises = paisRepository.getAllCountries();
        for (Pais pais : paises){
            System.out.println(pais.getNome());
        }
    }
}
