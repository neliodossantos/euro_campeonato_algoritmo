import config.Database;
import repositories.*;
import seeds.SeedInitializer;
import services.Service;
import utils.ScreenUtils;
import java.sql.SQLException;
import java.util.Scanner;

public class Euro {

    public static void main(String[] args) throws SQLException {
        Scanner scanner = new Scanner(System.in);
        ScreenUtils screen = new ScreenUtils();
        Database db = new Database();
        db.getConnection();
        screen.pause("Carregando os dados.....");
        Service service = new Service(db);
        SeedInitializer seed = new SeedInitializer(service.simularService,db);
        seed.popularTabelas();
        boolean running = true;
        while (running) {
            System.out.println("=======================================");
            System.out.println("==========   Euro 2024   ==============");
            System.out.println("=======================================");
            System.out.println("1. Adicionar Informação");
            System.out.println("2. Consultar Dados");
            System.out.println("3. Simular a fase de qualificacao");
            System.out.println("0. Sair");
            System.out.print("Escolha uma opção: ");
            int choice = scanner.nextInt();
            switch (choice) {
                case 1:
                    adicionarInformacao(scanner,screen,service);
                    break;
                case 2:
                    consultarDados(scanner,screen,service);
                    break;
                case 3:
                    if(seed.simularEuro()){
                        System.out.println("Simulacao feita com sucesso...");
                    }else{
                        System.out.println("Ja foi simulado o euro");
                        seed.simularNovamente();
                    }
                    break;
                case 0:
                    running = false;
                    System.out.println("Saindo...");
                    break;
                default:
                    System.out.println("Opção inválida. Tente novamente.");
                    break;
            }
        }
        scanner.close();
    }
    public static void adicionarInformacao(Scanner scanner, ScreenUtils screen , Service service) throws SQLException {
        System.out.println("=== Adicionar Informação ===");
        System.out.println("1. Adicionar Seleção");
        System.out.println("2. Adicionar Jogador");
        System.out.println("3. Adicionar Estádio");
        System.out.println("4. Adicionar Cidade");
        System.out.println("5. Adicionar Pais");
        System.out.println("6. Adicionar Grupo");
        System.out.println("7. Voltar ao Menu Principal");
        System.out.print("Escolha uma opção: ");

        int choice = scanner.nextInt();

        switch (choice) {
            case 1:
                service.selecaoService.criarSelecao(scanner);
                break;
            case 2:
                service.jogadorService.criarJogador(scanner);
                break;
            case 3:
                service.estadioService.criarEstadio(scanner);
                break;
            case 4:
                service.cidadeService.criarCidade(scanner);
                break;
            case 5:
                service.paisService.criarPais(scanner);
                break;
            case 6:
                service.grupoService.criarGrupo(scanner);
                break;
            case 7:
                return;
            default:
                System.out.println("Opção inválida. Tente novamente.");
                break;
        }
        screen.clear();
    }

    public static void consultarDados(Scanner scanner,ScreenUtils screen, Service service) throws SQLException {
        System.out.println("=== Consultar Dados ===");
        System.out.println("1. Consultar todos os Grupo");
        System.out.println("2. Consultar um Grupo");
        System.out.println("3. Consultar todos Jogadores de uma equipe");
        System.out.println("4. Consultar selecoes");
        System.out.println("5. Consultar pais");
        System.out.println("6. Consultar estadios");
        System.out.println("7. Consultar cidades");
        System.out.println("8. Consultar uma Partida");
        System.out.println("9. Consultar Classificação");
        System.out.println("10. Consultar Estatistica de um Jogador");
        System.out.println("11. Consultar Estatistica de uma equipa");
        System.out.println("12. Consultar melhor marcador");
        System.out.println("13. Consultar melhor assistente");
        System.out.println("14. Consultar equipes apuradas");
        System.out.println("15. Voltar ao Menu Principal");
        System.out.print("Escolha uma opção: ");

        int choice = scanner.nextInt();

        screen.clear();

        switch (choice) {
            case 1:
                service.grupoRepository.mostrarGruposESelecoes();
                break;
            case 2:
                service.grupoService.listarGrupo(scanner);
                break;
            case 3:
                service.selecaoService.listarSelecao(scanner);
            case 4:
                service.selecaoService.listarJogadoresSelecao(scanner);
                break;
            case 5:
                service.paisService.listarPais(scanner);
                break;
            case 6:
                service.estadioService.listarEstadio(scanner);
                break;
            case 7:
                service.cidadeService.listarCidade(scanner);
                break;
            case 8:
                service.partidaService.imprimirPartida(scanner);
                break;
            case 9:
                service.grupoRepository.mostrarClassificacaoGrupos();
                break;
            case 10:
                service.jogadorService.imprimirEstatisticasJogador(scanner);
                break;
            case 11:
                service.selecaoService.imprimirEstatisticaSelecao(scanner);
                break;
            case 12:
                service.jogadorService.listarMelhoresMarcadores();
                break;
            case 13:
                break;
            case 14:
                service.grupoRepository.mostrar2ClassificacaoGrupos();
                break;
            case 15:
                break;
            default:
                System.out.println("Opção inválida. Tente novamente.");
                break;
        }
    }
}
